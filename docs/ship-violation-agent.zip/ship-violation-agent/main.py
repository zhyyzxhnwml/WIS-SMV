"""
船舶违规检测智能体 — 运行入口
===============================

【使用方式 — 新增: 从 CSV 文件读数据并输出结果】
  1. pip install -r requirements.txt
  2. 确保 Ollama 运行: ollama serve
  3. 运行 CSV 文件处理模式:

     # 处理 data/input/ 下的所有 CSV 文件
     python main.py --mode file

     # 指定输入输出目录
     python main.py --mode file --input data/input --output data/output

     # 限制处理的船舶数量（对大文件很有用）
     python main.py --mode file --max-ships 10

  4. 运行单个 CSV 文件:
     python main.py --mode file --input data/input/sample_ships.csv

  5. 旧版演示模式（使用内置示例数据）:
     python main.py

【项目结构】
  ship-violation-agent/
  ├── main.py                   ← 运行入口（本文件）
  ├── requirements.txt          ← 依赖清单
  ├── regulations.json          ← 规则库
  ├── data/
  │   ├── input/                ← 存放输入 CSV 数据文件
  │   │   ├── sample_ships.csv  ← 标准格式示例数据
  │   │   └── ais_sample.csv    ← 原始 AIS 格式数据
  │   └── output/               ← 分析结果 CSV 输出目录
  └── ship_agent/               ← 智能体核心包
      ├── config.py             ← 配置管理
      ├── models.py             ← 数据模型
      ├── tools.py              ← 工具函数
      ├── agents.py             ← 智能体定义 + 工作流
      └── data_processor.py     ← CSV 数据读写处理

【智能体架构】
         输入船舶数据
              │
              ▼
       ┌──────────────┐
       │ 输入校验      │
       │ (Pydantic)    │
       └──────┬───────┘
              │
       ┌──────▼───────┐
       │ 规则引擎智能体  │  ← geo_fence, regulation 工具
       └──────┬───────┘
              │
       ┌──────▼───────┐
       │ 轨迹分析智能体  │  ← speed, trajectory 工具
       └──────┬───────┘
              │
       ┌──────▼───────┐
       │ AIS验证智能体   │  ← registry, trajectory 工具
       └──────┬───────┘
              │
       ┌──────▼───────┐
       │ 主控智能体     │  ← 综合判决
       └──────┬───────┘
              │
              ▼
        ┌──────────┐
        │ 违规判定  │
        │ + 证据链  │
        └──────────┘
"""

import argparse   # 命令行参数解析
import json       # JSON 读写
import sys        # 系统相关（标准输入输出、退出）
import io         # IO 工具
from pathlib import Path   # 路径处理

# Windows 控制台编码修复
# Windows 的 CMD/PowerShell 默认用 GBK 编码,
# 但我们的代码（规则、日志）都是 UTF-8。
# 这里把标准输出设为 UTF-8, 避免中文乱码。
if sys.platform == "win32":
    # TextIOWrapper 把字节流包装成文本流, 强制指定编码
    # errors="replace" — 遇到无法编码的字符用 ? 替代, 而不是崩溃
    sys.stdout = io.TextIOWrapper(
        sys.stdout.buffer, encoding="utf-8", errors="replace"
    )
    sys.stderr = io.TextIOWrapper(
        sys.stderr.buffer, encoding="utf-8", errors="replace"
    )

# 将项目根目录加入 Python 路径
# 这样 import ship_agent 才能找到（类似 Java 的 classpath）
# str() 把 Path 转成字符串
sys.path.insert(0, str(Path(__file__).resolve().parent))

from loguru import logger

# 配置日志（去掉默认的 handler, 避免重复输出）
logger.remove()
# 输出到控制台: 带颜色 + 时间 + 日志级别
logger.add(
    sys.stdout,
    format="<green>{time:HH:mm:ss}</green> | <level>{level:8}</level> | {message}",
    level="INFO",   # 只输出 INFO 及以上
)
# 输出到文件: 详细信息 + 自动切割
# rotation="10 MB" — 文件超过 10MB 就新建一个
logger.add(
    "logs/violation_detector.log",
    rotation="10 MB",
    level="DEBUG",  # 文件里记 DEBUG 级别, 调试时能看到更多信息
    format="{time} | {level:8} | {message}",
)


# 1. 初始化 LLM

def init_llm():
    """初始化 Qwen 本地模型

    使用 ChatOllama 连接到本地运行的 Ollama 服务。
    Ollama 需要在后台运行: 终端执行 `ollama serve`

    如果报错 "Connection refused", 说明 Ollama 没启动:
      终端运行: ollama serve
      或者: ollama run qwen2.5:7b-instruct-q4_K_M
    """
    # 延迟导入 — 让 main.py 在没装 langchain 时也能 --help
    from langchain_ollama import ChatOllama

    from ship_agent.config import LLM_CONFIG

    config = LLM_CONFIG["ollama"]
    logger.info(f"正在连接 Ollama 模型: {config['model']}")

    # ChatOllama 是 LangChain 提供的 Ollama 客户端
    # 各种参数控制 LLM 行为, 详细说明见 config.py 里的注释
    llm = ChatOllama(
        model=config["model"],
        temperature=config["temperature"],
        num_predict=config["num_predict"],
        top_k=config["top_k"],
        top_p=config["top_p"],
        repeat_penalty=config["repeat_penalty"],
        num_ctx=config["num_ctx"],
        base_url=config["base_url"],
    )

    # 测试连接是否正常
    try:
        # llm.invoke("...") 是调用 LLM 生成回复的标准方式
        test_response = llm.invoke("回复OK表示连接正常")
        # .content 提取 AI 的文本回复
        logger.info(f"Ollama 连接成功! 模型回复: {test_response.content[:50]}")
    except Exception as e:
        # sys.exit(1) 表示"非正常退出", 数字 1 是退出码, 0 表示成功
        logger.error(f"Ollama 连接失败: {e}")
        logger.error("请确保: 1) Ollama 已安装 2) 'ollama serve' 正在运行")
        logger.error("       3) 模型已下载: ollama pull qwen2.5:7b-instruct-q4_K_M")
        sys.exit(1)

    return llm


# 2. 打印结果（美化输出）

def print_result(result: dict):
    """美化输出分析结果到终端

    Args:
        result: ShipViolationDetector.analyze() 返回的字典
    """
    # 60 个等号 — 画分隔线
    dash = "═" * 60

    print(f"\n{dash}")
    print(f"📋 违规判定结果")
    print(dash)

    # .get(key, default) — 取不到就用默认值, 不会 KeyError
    violation = result.get("violation_detected", False)
    label = result.get("violation_label", "未知")
    confidence = result.get("confidence", 0)
    risk = result.get("risk_level", "low")
    action = result.get("recommended_action", "monitor")

    # 状态图标 — 用 emoji 让结果更直观
    icon = "🔴" if violation else "🟢"
    # 字典.get(key, default) — 找不到用默认 ❓
    risk_icon = {"high": "🚨", "middle": "⚠️", "low": "✅"}.get(risk, "❓")

    mmsi = result.get("mmsi", "")
    ship_name = result.get("ship_name", "")
    ship_type = result.get("ship_type", "")

    print(f"\n🚢 {ship_name or mmsi} ({ship_type})")
    print(f"{icon} 违规判定: {'违规!' if violation else '正常'}")
    if violation:
        print(f"   ├─ 违规类型: {result.get('violation_type', '未知')}")
        print(f"   ├─ 违规描述: {label}")
    print(f"   ├─ 置信度: {confidence:.1%}")   # .1% 表示 1 位小数的百分比
    print(f"   ├─ 风险等级: {risk_icon} {risk}")
    print(f"   └─ 建议操作: {action}")

    # 证据链
    evidence = result.get("evidence_chain", [])
    if evidence:
        print(f"\n📎 证据链 ({len(evidence)} 条)")
        print("-" * 40)
        # enumerate(..., 1) 下标从 1 开始, 更符合"证据1、证据2"的习惯
        for i, ev in enumerate(evidence, 1):
            print(f"  [{i}] {ev.get('agent_name', '未知')}")
            finding = ev.get('finding', '无')
            # 截断过长文字, 避免一行刷屏
            if len(str(finding)) > 100:
                finding = str(finding)[:97] + "..."
            print(f"      发现: {finding}")
            print(f"      置信度: {ev.get('confidence', 0):.1%}")

    # 综合说明
    assessment = result.get("final_assessment")
    if assessment:
        print(f"\n💡 综合判定说明:")
        if len(str(assessment)) > 200:
            print(f"   {str(assessment)[:197]}...")
        else:
            print(f"   {assessment}")

    # 错误信息
    errors = result.get("errors", [])
    if errors:
        print(f"\n❌ 处理过程中的错误:")
        for err in errors:
            print(f"   - {err}")

    print(f"{dash}\n")


# 3. 演示模式（使用内置示例数据）

def run_demo_mode():
    """运行内置示例的演示模式（旧版默认行为）

    适合: 第一次跑系统, 快速验证 LLM 是否通。
    """
    from ship_agent.models import get_sample_input

    logger.info("=" * 50)
    logger.info("船舶违规检测智能体 启动中...")
    logger.info("=" * 50)

    llm = init_llm()

    from ship_agent.agents import ShipViolationDetector
    detector = ShipViolationDetector(llm)

    # 获取示例数据
    ship_data = get_sample_input()

    print(f"\n{'─' * 60}")
    print(f"🚢 待分析船舶: {ship_data['ship']['name']}")
    print(f"   MMSI: {ship_data['ship']['mmsi']}")
    print(f"   类型: {ship_data['ship']['ship_type']}")
    print(f"   当前位置: ({ship_data['current_position']['lat']}, "
          f"{ship_data['current_position']['lon']})")
    print(f"   航速: {ship_data['current_position']['speed']} 节")
    print(f"   当前区域: {ship_data['context'].get('current_zone', '未知')}")
    print(f"   时间: {ship_data['context'].get('time_info', '未知')}")
    print(f"{'─' * 60}\n")

    # 执行分析
    logger.info("开始分析...")
    logger.info("该过程需要调用 3 个子智能体 + 1 个主控智能体")
    logger.info("请耐心等待...\n")

    result = detector.analyze(ship_data)

    # 补充船舶标识信息到结果, 后面展示用
    result["mmsi"] = ship_data["ship"]["mmsi"]
    result["ship_name"] = ship_data["ship"]["name"]
    result["ship_type"] = ship_data["ship"]["ship_type"]

    print_result(result)

    # 保存结果到 JSON
    output_path = Path("output") / f"result_{ship_data['ship']['mmsi']}.json"
    # parents=True 兼容深层路径; exist_ok=True 已存在不报错
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        # ensure_ascii=False: 中文不转 \uXXXX, 直接写人话
        # indent=2: 缩进 2 格, 看起来更易读
        json.dump(result, f, ensure_ascii=False, indent=2)
    logger.info(f"结果已保存到: {output_path}")

    logger.info("分析完成!")


# 4. 文件处理模式 — 从 data/input/ 读 CSV → 输出到 data/output/

def run_file_mode(input_path: str, output_dir: str, max_ships: int = 0,
                  max_workers: int = 4):
    """从 CSV 文件读取数据, 分析后输出为 CSV

    适合: 真实场景下批量分析大量船舶。

    Args:
        input_path: CSV 文件路径 或 目录路径
        output_dir: 输出目录路径
        max_ships: 最多处理船舶数（0 = 不限）
    """
    # 延迟导入 — 节省启动时间
    from ship_agent.agents import ShipViolationDetector
    from ship_agent.data_processor import (
        load_all_ships_from_csv,
        list_input_csvs,
        save_results_to_csv,
        detect_csv_format,
    )

    logger.info("=" * 50)
    logger.info("船舶违规检测智能体 — 文件处理模式")
    logger.info("=" * 50)

    llm = init_llm()
    detector = ShipViolationDetector(llm)

    # 确定输入文件列表
    # is_file() / is_dir() — Path 的方法, 区分文件和目录
    input_p = Path(input_path)
    if input_p.is_file():
        csv_files = [input_p]   # 单个文件 → 包成列表
    elif input_p.is_dir():
        csv_files = list_input_csvs(input_path)   # 目录 → 列出所有 CSV
    else:
        logger.error(f"输入路径不存在: {input_path}")
        sys.exit(1)

    if not csv_files:
        logger.error("没有找到可处理的 CSV 文件")
        sys.exit(1)

    # 确保输出目录存在
    output_p = Path(output_dir)
    output_p.mkdir(parents=True, exist_ok=True)

    # 用于汇总所有结果
    all_results = []

    # 处理每个 CSV 文件
    for csv_file in csv_files:
        logger.info(f"\n{'='*60}")
        logger.info(f"📄 处理文件: {csv_file.name}")
        # str() — Path 转字符串
        logger.info(f"   格式: {detect_csv_format(str(csv_file))}")
        logger.info(f"{'='*60}")

        # 读取
        # None 是"不限"; max_ships=0 转成 None 传给底层
        ships_data = load_all_ships_from_csv(
            str(csv_file),
            max_ships if max_ships > 0 else None
        )
        if not ships_data:
            logger.warning("   文件中没有有效船舶数据, 跳过")
            continue

        logger.info(f"   共 {len(ships_data)} 条船舶待分析")

        # 并行批量分析（analyze_batch 内部使用 ThreadPoolExecutor）
        # 自动处理：并行调度 + 错误隔离 + 船舶标识补充
        file_results = detector.analyze_batch(
            ships_data, max_workers=max_workers
        )
        all_results.extend(file_results)

        # 输出日志摘要
        for result in file_results:
            violation = result.get("violation_detected", False)
            conf = result.get("confidence", 0)
            icon = "🔴" if violation else "🟢"
            name = result.get("ship_name", "") or result.get("mmsi", "")
            logger.info(f"   {icon} {name}: {'违规' if violation else '正常'} "
                       f"(置信度: {conf:.1%})")

        # 保存当前文件的 CSV 结果
        if file_results:
            # 用原文件名作为结果文件名前缀, 便于溯源
            timestamp = Path(csv_file).stem   # .stem 是去掉后缀的文件名
            output_filename = f"results_{timestamp}.csv"
            output_path = str(output_p / output_filename)
            save_results_to_csv(file_results, output_path)

    # 输出汇总
    if all_results:
        total = len(all_results)
        # sum + 生成器表达式 — 数违规的有几个
        violations = sum(
            1 for r in all_results if r.get("violation_detected")
        )
        print(f"\n{'═' * 60}")
        print(f"📊 处理完成汇总")
        print(f"{'═' * 60}")
        print(f"   总处理船舶: {total}")
        # 避免 total=0 时除零
        if total > 0:
            print(f"   发现违规:   {violations} 艘 ({violations/total*100:.1f}%)")
        else:
            print(f"   发现违规:   0 艘")
        # .resolve() 转绝对路径, 方便用户找
        print(f"   输出目录:   {output_p.resolve()}")
        print(f"{'═' * 60}\n")


# 5. 命令行参数解析

def parse_args():
    """解析命令行参数

    argparse 是 Python 标准库的"命令行参数解析器"。
    它的核心概念:
      - ArgumentParser: 总入口
      - add_argument: 加一个参数定义
      - parse_args(): 真正解析 (sys.argv)

    Returns:
        解析后的参数对象, 通过 .属性名 访问
    """
    parser = argparse.ArgumentParser(
        description="船舶违规检测智能体",
        # RawDescriptionHelpFormatter 保留 epilog 里的换行
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 演示模式（默认, 使用内置数据）
  python main.py

  # 文件处理模式 — 处理 data/input/ 下所有 CSV
  python main.py --mode file

  # 指定输入目录和输出目录
  python main.py --mode file --input data/input --output data/output

  # 处理单个 CSV 文件, 最多 5 条船
  python main.py --mode file --input data/input/sample_ships.csv --max-ships 5

  # 处理原始 AIS CSV 文件, 用 8 个线程并行
  python main.py --mode file --input data/input/ais_sample.csv --max-ships 10 --workers 8
        """
    )

    parser.add_argument(
        "--mode", "-m",   # 同时支持长/短选项
        type=str,
        default="demo",
        # choices 限定取值, 写错会有友好提示
        choices=["demo", "file", "stream"],
        help="运行模式: demo(内置示例) | file(从 CSV 文件批量读取) | stream(流式处理 CSV)"
    )

    parser.add_argument(
        "--input", "-i",
        type=str,
        default="data/input",
        help="输入 CSV 文件或目录路径（仅 file 模式有效）"
    )

    parser.add_argument(
        "--output", "-o",
        type=str,
        default="data/output",
        help="输出目录路径（仅 file 模式有效）"
    )

    parser.add_argument(
        "--max-ships", "-n",
        type=int,
        default=0,
        help="最多处理船舶数, 0 = 不限（对大文件很有用）"
    )

    parser.add_argument(
        "--workers", "-w",
        type=int,
        default=4,
        help="并行分析线程数（默认 4，增大可加速大批量数据，但过大会让 Ollama 过载）"
    )

    parser.add_argument(
        "--batch-test",
        # action="store_true" — 不写这个参数就是 False, 写了就是 True
        action="store_true",
        help="运行内置批量测试（仅 demo 模式可用）"
    )

    parser.add_argument(
        "--delay",
        type=float,
        default=0,
        help="流模式下行间延迟秒数（默认 0，模拟实时流时设置，如 0.01）"
    )

    return parser.parse_args()


# 6. 批量测试（内置场景）

def run_batch_test(detector):
    """批量测试示例 — 跑几个固定场景验证系统

    Args:
        detector: 已经初始化好的 ShipViolationDetector
    """
    test_cases = [
        {
            "name": "测试1: 正常航行货轮",
            "data": {
                "ship": {"mmsi": "412345679", "name": "GLOBAL-TRADER",
                         "ship_type": "集装箱船"},
                "current_position": {"lat": 38.5000, "lon": 122.0000,
                                     "speed": 15.0, "course": 90.0,
                                     "timestamp": "2026-07-11T08:00:00Z",
                                     "status": "underway"},
                "history": [],
                "context": {"current_zone": "公海", "time_info": "正常"}
            }
        },
        {
            "name": "测试2: 禁航区入侵",
            "data": {
                "ship": {"mmsi": "412345680", "name": "INTRUDER",
                         "ship_type": "散货船"},
                "current_position": {"lat": 38.6000, "lon": 122.1000,
                                     "speed": 10.0, "course": 45.0,
                                     "timestamp": "2026-07-11T08:00:00Z",
                                     "status": "underway"},
                "history": [],
                "context": {"current_zone": "军事禁区B", "time_info": "正常"}
            }
        },
    ]

    logger.info("开始批量测试...")
    for case in test_cases:
        logger.info(f"\n{'='*40}")
        logger.info(f"运行: {case['name']}")
        logger.info(f"{'='*40}")
        try:
            result = detector.analyze(case["data"])
            result["mmsi"] = case["data"]["ship"]["mmsi"]
            result["ship_name"] = case["data"]["ship"]["name"]
            result["ship_type"] = case["data"]["ship"]["ship_type"]
            print_result(result)
        except Exception as e:
            logger.error(f"测试失败 [{case['name']}]: {e}")


# 入口

if __name__ == "__main__":
    # 经典 Python 入口写法:
    # 当文件被直接执行时, __name__ == "__main__"
    # 当文件被 import 时, __name__ 是模块名, 这段不会执行
    # 这样模块既可以"被当库用", 又可以"直接跑"

    args = parse_args()

    if args.mode == "stream":
        # 流式处理模式
        from ship_agent.stream_engine import run_stream_from_csv

        llm = init_llm()
        run_stream_from_csv(
            csv_path=args.input,
            llm=llm,
            max_ships=args.max_ships,
            max_workers=args.workers,
            delay_per_row=args.delay,
        )
    elif args.mode == "file":
        # 文件处理模式
        run_file_mode(
            input_path=args.input,
            output_dir=args.output,
            max_ships=args.max_ships,
            max_workers=args.workers,
        )
    else:
        # 演示模式
        if args.batch_test:
            # 批量测试需要先初始化 LLM 和 detector
            llm = init_llm()
            from ship_agent.agents import ShipViolationDetector
            detector = ShipViolationDetector(llm)
            run_batch_test(detector)
        else:
            run_demo_mode()
