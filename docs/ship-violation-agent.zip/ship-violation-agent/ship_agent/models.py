
"""
船舶违规检测智能体 — 数据模型模块
====================================

【这个文件做什么？】
  定义数据的"形状" — 进入系统的数据长什么样、出去的数据长什么样。
  类似填表: 规定表里要有哪些字段、字段是什么类型、字段值要满足什么条件。

【Pydantic v2 是什么？】
  现在的 Python 数据校验"事实标准"。
  作用:
    1. 类型安全 — 传错类型立刻报错，不会运行到一半崩
    2. IDE 友好 — 写代码时能自动补全
    3. 自文档化 — 字段的 description 自动生成 API 文档
    4. 序列化 — .model_dump() 一键转 dict，方便存 JSON/给前端

【几个 Python 概念先补一下】
  1. BaseModel（基类）
     → Pydantic 里所有数据模型都要继承它。就像做表格先要"画个表头"。
  2. Field(...)
     → 给字段加约束和说明。... 是必填的意思。
  3. Optional[X] = None
     → 字段可以不存在，缺了默认是 None。
  4. List[X]
     → 列表，里面的元素都是 X 类型。
  5. @field_validator
     → 自定义校验器。可以在数据进入系统时做清洗/转换。
  6. default_factory=list
     → 默认值是一个"新的空列表"。注意: 不能直接 default=[],
       因为 [] 是可变对象，default 会让所有实例共享同一个列表（坑）。
"""

from datetime import datetime      # 时间处理
from typing import Optional, List  # 类型注解
from pydantic import BaseModel, Field, field_validator


# 输入数据模型 — 进来的是什么

class ShipPosition(BaseModel):
    """船舶位置数据 — 对应 AIS 数据中的一条位置报告

    AIS (Automatic Identification System) = 船舶自动识别系统,
    船每隔几秒会自动广播自己位置、速度、航向等，类似飞机黑匣子。

    Field 参数说明:
      ...        : 必填
      description: 字段说明（自动出现在 API 文档里）
      ge / le    : 数值范围约束（ge = greater or equal, le = less or equal）
      examples   : 示例值
      pattern    : 正则表达式（字符串字段用）
    """
    lat: float = Field(
        ..., description="纬度 (°)", ge=-90, le=90,
        examples=[38.1234]   # 纬度范围 -90° ~ +90°
    )
    lon: float = Field(
        ..., description="经度 (°)", ge=-180, le=180,
        examples=[121.5678]  # 经度范围 -180° ~ +180°
    )
    speed: float = Field(
        ..., description="航速 (节)", ge=0, le=102.3,
        examples=[12.5]      # 1 节 = 1 海里/小时 ≈ 1.85 km/h, 最快船约 100 节
    )
    course: float = Field(
        ..., description="航向 (°, 0=正北, 顺时针)", ge=0, le=360,
        examples=[135.0]     # 0=北, 90=东, 180=南, 270=西
    )
    timestamp: datetime = Field(
        ..., description="UTC 时间戳"
        # datetime 类型 Pydantic 会自动解析 "2026-07-11T08:30:00Z" 这样的字符串
    )
    status: Optional[str] = Field(
        default=None,        # default=None 表示这个字段可以没有
        description="航行状态",
        examples=["underway", "fishing", "anchored"]
        # underway=航行中, fishing=捕捞, anchored=抛锚
    )

    # 自定义校验器（数据进来时做清洗）
    @field_validator("status", mode="before")
    @classmethod
    def normalize_status(cls, v: Optional[str]) -> Optional[str]:
        """统一航行状态为小写，避免后续匹配时大小写不一致

        Pydantic 校验器要点:
          - @field_validator("字段名", mode="before")
            mode="before" 表示在 Pydantic 基础校验之前先跑这个函数
          - @classmethod 表示这是个类方法（不是实例方法）
          - cls 是类本身，类似 self 但代表"类"
          - v 是该字段的原始值
        """
        if v is None:
            return None
        # .lower() 转小写, .strip() 去首尾空格 — 数据清洗
        return v.lower().strip()


class ShipInfo(BaseModel):
    """船舶基本信息

    MMSI = Maritime Mobile Service Identity（海上移动业务标识码），
    是船舶的"身份证号"，全球唯一，9 位数字，类似手机号。
    """
    mmsi: str = Field(
        ..., description="MMSI (9位数字)",
        pattern=r"^\d{9}$",   # 正则: ^开头, \d{9} 9个数字, $结尾
        examples=["412345678"]
    )
    name: Optional[str] = Field(default=None, description="船名")
    ship_type: Optional[str] = Field(default=None, description="船舶类型")
    length: Optional[float] = Field(default=None, description="船长 (米)")
    width: Optional[float] = Field(default=None, description="船宽 (米)")


class ShipData(BaseModel):
    """单条完整的船舶分析输入 — 整个系统的输入标准格式

    这个类定义了"喂给系统的数据长什么样"，类似函数签名。
    所有调用 detector.analyze() 的地方都要传符合这个结构的数据。

    设计选择: history 用 List[dict] 而不是 List[ShipPosition]
      因为历史数据可能来自不同来源（JSON、CSV），
      用 dict 更灵活。实际使用时可按需转成 ShipPosition。
    """
    ship: ShipInfo                                   # 必填: 船舶基本信息
    current_position: ShipPosition                   # 必填: 当前位置
    history: List[dict] = Field(
        default_factory=list,    # 默认空列表（用 default_factory 是为了每次新建空列表）
        description="历史轨迹点列表（每个元素同 ShipPosition 结构）"
    )
    context: dict = Field(
        default_factory=dict,    # 默认空字典
        description="上下文信息，如 current_zone, time_info, nearby_ships 等"
    )


# 输出数据模型 — 出去的是什么

class AgentFinding(BaseModel):
    """子智能体的分析结果 — 构成证据链的一个环节

    证据链: 类似法官判案时要列出"证据 1, 证据 2, ..."。
    这里每个子智能体（规则引擎/轨迹/AIS）的输出都是一条证据。
    """
    agent_name: str = Field(..., description="智能体名称")
    finding: str = Field(..., description="分析发现（文字）")
    confidence: float = Field(
        ..., description="置信度 (0~1)", ge=0, le=1
        # 0=完全没把握, 1=100% 把握
    )
    details: Optional[dict] = Field(
        default=None, description="详细支撑数据"
    )


class ViolationResult(BaseModel):
    """最终违规判定 — 系统的输出标准格式

    设计原则:
      - 所有字段都有默认值 → 即使部分分析失败也能正常输出
      - evidence_chain 保留推理过程 → 方便出问题时回溯
      - errors 记录处理中的问题 → 方便调试
    """
    violation_detected: bool = Field(
        default=False, description="是否检测到违规"
    )
    violation_type: Optional[str] = Field(
        default=None, description="违规类型代码（如 illegal_fishing）"
    )
    violation_label: Optional[str] = Field(
        default=None, description="违规中文描述（如 非法捕捞）"
    )
    confidence: float = Field(
        default=0.0, description="综合置信度 (0~1)"
    )
    risk_level: str = Field(
        default="low", description="风险等级: high / middle / low"
    )
    evidence_chain: List[AgentFinding] = Field(
        default_factory=list, description="证据链（推理过程）"
    )
    final_assessment: Optional[str] = Field(
        default=None, description="综合判定说明（自然语言）"
    )
    recommended_action: str = Field(
        default="monitor",
        description="建议操作: auto_alert（自动报警）/ manual_review（人工复核）/ monitor（继续观察）"
    )
    errors: List[str] = Field(
        default_factory=list, description="处理过程中的错误信息"
    )


# 示例数据（用于测试）

def get_sample_input() -> dict:
    """生成一个示例输入，方便测试时使用

    场景: "OCEAN-KING" 拖网渔船在禁渔区A内低速行驶，
    且当前是禁渔期 — 是典型的"非法捕捞"违规场景。

    Returns:
        dict: 符合 ShipData 结构的字典

    注意: 返回的是普通 dict，不是 ShipData 对象。
    调用方如果需要校验，可以 ShipData(**result)。
    """
    return {
        "ship": {
            "mmsi": "412345678",
            "name": "OCEAN-KING",
            "ship_type": "拖网渔船",
            "length": 35.0,    # 35 米长
            "width": 8.0       # 8 米宽
        },
        "current_position": {
            "lat": 38.1234,
            "lon": 121.5678,
            "speed": 0.8,            # ← 极低速，疑似捕捞（船在作业时一般 < 3 节）
            "course": 180.0,         # 朝正南
            "timestamp": "2026-07-11T08:30:00Z",   # Z 表示 UTC
            "status": "fishing"      # 状态是"捕捞"
        },
        "history": [
            # 进入禁渔区前的正常航行（速度 ~11 节）
            {"lat": 38.0800, "lon": 121.4800, "speed": 11.2, "course": 135.0,
             "timestamp": "2026-07-11T06:00:00Z"},
            {"lat": 38.0950, "lon": 121.5100, "speed": 11.5, "course": 140.0,
             "timestamp": "2026-07-11T06:15:00Z"},
            {"lat": 38.1100, "lon": 121.5400, "speed": 10.8, "course": 138.0,
             "timestamp": "2026-07-11T06:30:00Z"},
            # 进入禁渔区后速度骤降到 1-2 节 — 典型的"放网捕捞"行为模式
            {"lat": 38.1180, "lon": 121.5550, "speed": 2.1, "course": 170.0,
             "timestamp": "2026-07-11T07:00:00Z"},
            {"lat": 38.1200, "lon": 121.5600, "speed": 1.2, "course": 175.0,
             "timestamp": "2026-07-11T07:30:00Z"},
            {"lat": 38.1220, "lon": 121.5620, "speed": 0.9, "course": 180.0,
             "timestamp": "2026-07-11T08:00:00Z"},
        ],
        "context": {
            "current_zone": "禁渔区A",
            "time_info": "禁渔期（5月1日-9月1日）",
            "nearby_ships": 3,
            "weather": "晴，能见度良好"
        }
    }
