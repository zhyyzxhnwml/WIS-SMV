"""
船舶违规检测智能体 — 配置模块
==============================

【这个文件做什么？】
  把"配置"集中放在一起，不在代码里到处写死。
  这是 12-Factor App（现代应用部署方法论）里的原则之一：
  "Config in env, code in files" — 配置放环境变量，代码是固定的。

【几个 Python 概念先补一下】
  1. os.getenv(名字, 默认值)
     → 读系统环境变量。例: os.getenv("PATH", "") 表示读 PATH，找不到就用空串。
  2. Path 对象
     → 来自 pathlib 模块，是"路径的面向对象版本"。
       Path("a/b/c.txt") 比字符串 "a\\b\\c.txt" 好用：自动处理 / 和 \、能用 .exists()、.parent 等。
  3. 模块级变量
     → 不在函数/类里、写在最外层的变量。import 这个模块时就会执行（除了 if __name__ 这种）。
"""

import os          # 操作系统接口（读环境变量、路径等）
import json        # JSON 读写
from pathlib import Path   # 跨平台路径处理
from typing import Optional  # 类型注解，Optional[X] = X 或 None

from loguru import logger   # 第三方日志库，比标准 logging 好用


# ═══════════════════════════════════════════════════════════
# 路径配置（项目里所有需要用到的文件位置都集中在这里）
# ═══════════════════════════════════════════════════════════

# __file__ 是当前这个 .py 文件的路径（字符串）。
# .resolve() 把它转成绝对路径，并消除 ".." 之类的相对符号。
# .parent 是 "上一级目录"。
# 两次 .parent: config.py 在 ship_agent/ 里，所以要往上两级才到项目根目录。
# 结果类似: E:\ship-violation-agent
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# 用路径拼接的方式生成 regulations.json 的绝对路径（/ 拼接，跨平台都OK）
REGULATIONS_PATH = PROJECT_ROOT / "regulations.json"


# ═══════════════════════════════════════════════════════════
# LLM（大语言模型）配置
# ═══════════════════════════════════════════════════════════
#
# 关键参数解释:
#   temperature: 0=完全确定（同输入同输出），1=更随机。违规检测要稳定，设为 0。
#   num_predict: 最多生成多少个 token（模型输出长度上限）
#   top_k / top_p: 采样策略，控制"多样性"。一般不用动。
#   repeat_penalty: 防止模型重复啰嗦，1.1 表示轻微惩罚。
#   num_ctx: 上下文窗口（一次能"看到"多少 token）。越大越吃显存。

LLM_CONFIG = {
    # 本地 Ollama 配置
    # Ollama 是一个本地运行大模型的工具（类似 Docker 装模型）。
    # 用前要装 Ollama，然后: ollama pull qwen2.5:7b-instruct-q4_K_M 下载模型
    "ollama": {
        # os.getenv(环境变量名, 默认值) — 优先用环境变量，没设置就用默认值
        "model": os.getenv("OLLAMA_MODEL", "qwen2.5:7b-instruct-q4_K_M"),
        "base_url": os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"),
        "temperature": 0.0,      # 违规检测要确定性输出，不要随机性
        "num_predict": 2048,     # 一次最多生成 2048 个 token（约 1500 个汉字）
        "top_k": 40,
        "top_p": 0.9,
        "repeat_penalty": 1.1,
        "num_ctx": 8192,         # 上下文窗口 8K，够分析船舶数据
    },

    # 云端 API 配置（可选，目前用不到）
    "cloud": {
        "api_key": os.getenv("CLOUD_API_KEY", ""),
        "model": os.getenv("CLOUD_MODEL", "gpt-4o-mini"),
        "base_url": os.getenv("CLOUD_BASE_URL", ""),
    },
}


# ═══════════════════════════════════════════════════════════
# 检测阈值（判断违规的"分数线"）
# ═══════════════════════════════════════════════════════════
#
# 这些值就是经验值，可以根据实际跑出来的效果调。
# 类似考试: 90分优秀, 60分及格, 60分以下不及格。

THRESHOLDS = {
    "auto_alert": 0.85,           # 置信度 > 85% → 自动报警
    "manual_review": 0.60,        # 60%~85% → 人工复核
    # 置信度 < 60% → 不报警，继续观察

    "speed_anomaly_ratio": 0.3,   # 速度变化超过平均速度的 30% 视为异常
    "ais_gap_minutes": 30,        # AIS 信号丢失超过 30 分钟视为异常
}


# ═══════════════════════════════════════════════════════════
# 规则库加载函数
# ═══════════════════════════════════════════════════════════

def load_regulations() -> dict:
    """加载规则库 JSON 文件

    Returns:
        dict: 规则库内容，结构: {
            "zones": [区域列表],
            "ship_types": {船型映射},
            "violation_types": {违规类型定义}
        }

    【异常处理思路】
      文件读不到 / JSON 格式坏掉时，不要让整个程序崩溃，
      而是返回"空规则库"（用 .get("zones", []) 容错）。
      这样 LLM 拿不到规则也能继续跑（虽然会判定不违规），
      系统不会因为一个配置文件出问题就全挂。
    """
    # .exists() 检查文件是否存在（比 try/except 简洁）
    if not REGULATIONS_PATH.exists():
        logger.warning(f"规则文件不存在: {REGULATIONS_PATH}，使用空规则")
        # 返回一个"安全"的默认值，结构正常但内容是空
        return {"zones": [], "ship_types": {}, "violation_types": {}}

    try:
        # with open(...) as f: 是 Python 的"上下文管理器"
        # 作用: 离开 with 块时自动关闭文件，不用手动 f.close()
        # encoding="utf-8" 是为了正确读中文
        with open(REGULATIONS_PATH, "r", encoding="utf-8") as f:
            # json.load(文件对象) — 从文件读 JSON 并转成 Python 对象
            data = json.load(f)
        logger.info(f"已加载 {len(data.get('zones', []))} 个区域规则")
        return data
    except json.JSONDecodeError as e:
        # JSONDecodeError 是 json 模块的特定异常，比通用 Exception 更精确
        logger.error(f"规则文件格式错误: {e}")
        return {"zones": [], "ship_types": {}, "violation_types": {}}


# ═══════════════════════════════════════════════════════════
# 模块加载时自动执行
# ═══════════════════════════════════════════════════════════
#
# 这一行没有缩进，所以是模块级代码：只要别的文件 import 这个模块，
# 就会立即执行。好处是:
#   - 其他模块可以直接用 REGULATIONS 这个变量（已经准备好了）
#   - 不用每个用规则的文件都再调一次 load_regulations()
# 
# 代价: 第一次 import 略慢一点点。

REGULATIONS = load_regulations()
