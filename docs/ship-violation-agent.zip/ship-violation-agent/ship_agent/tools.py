"""
船舶违规检测智能体 — 工具函数模块
===================================

【这个文件做什么？】
  在 LangChain 中，工具（Tools）是智能体的"手脚"。
  LLM 负责"思考用什么工具"，工具负责"实际执行"。
  这种"思考→行动→再思考"的工作模式叫 ReAct (Reason + Act)。

【工具设计原则】
  1. 单一职责 — 一个工具只做一件事
  2. 描述清晰 — docstring 要让 LLM 一看就知道何时该用
  3. 输入输出结构化 — 方便 LLM 解析
  4. 错误处理 — 工具内部 try/except, 不要把异常抛到上层

【@tool 装饰器是什么？】
  from langchain.tools import tool
  加了这个装饰器，普通函数自动变成 Tool 对象，LLM 就能调用它。
  函数的 docstring 会被当做工具的 description（描述）。
  函数的参数名和类型注解，会变成工具的"参数模式"（告诉 LLM 该传什么）。

【几个 Python 概念先补一下】
  1. try / except
     → 异常处理。try 里放"可能出错的代码"，except 里放"出错时怎么办"。
  2. math.hypot(x, y)
     → 计算 sqrt(x*x + y*y)，即二维向量长度。
  3. datetime.fromisoformat(字符串)
     → 把 ISO 格式时间字符串解析为 datetime 对象。
  4. 列表切片 [a:b] / [::-1]
     → 截取片段 / 反转。
  5. Point(x, y) / Polygon([(x1,y1), (x2,y2), ...])
     → Shapely 库的几何对象。Point 是点，Polygon 是多边形。
       .contains(point) 判断"多边形是否包含这个点"。
  6. 可变默认参数陷阱
     → def f(x, items=[]): 这样写有 bug!
       因为 [] 只创建一次, 多次调用会共享。改用 None + 内部新建。
"""

import math                                  # 数学函数
from datetime import datetime, timedelta     # 时间处理
from typing import Optional                  # 类型注解

from langchain.tools import tool             # LangChain 工具装饰器
from loguru import logger                    # 日志

from ship_agent.config import REGULATIONS, THRESHOLDS  # 读规则库和阈值

# Shapely 是 GIS（地理信息系统）常用的库，做"点在多边形内"判断特别好用。
# try/except 是为了"装了更好用，没装也能跑" — 优雅降级。
try:
    from shapely.geometry import Point, Polygon
    HAS_SHAPELY = True
except ImportError:
    HAS_SHAPELY = False
    logger.warning("shapely 未安装，地理围栏功能将使用简化实现")


# 工具 1: 地理围栏检查

@tool
def geo_fence_check(
    lat: float,
    lon: float,
    ship_type: Optional[str] = None
) -> dict:
    """检查船舶当前所在的管制区域及该区域的限制规则。

    当需要知道"船在什么区域、这个区域有什么限制"时调用此工具。

    Args:
        lat: 纬度 (-90~90)
        lon: 经度 (-180~180)
        ship_type: 船舶类型（可选），例如 "拖网渔船"、"集装箱船"

    Returns:
        dict: {
            "in_zones": [区域列表],       # 船舶所在的管制区域
            "restrictions": [限制列表],   # 适用的限制规则
            "is_restricted": bool         # 是否在管制区域内
        }
    """
    # 参数边界检查 — 坐标不可能超出地球的范围
    if not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
        return {"error": f"坐标越界: ({lat}, {lon})", "in_zones": []}

    # 准备"点"对象。Shapely 用 (x=经度, y=纬度) 顺序，注意不是 (lat, lon)！
    point = Point(lon, lat) if HAS_SHAPELY else (lon, lat)
    # 从全局配置拿规则库里的所有区域
    zones = REGULATIONS.get("zones", [])
    found_zones = []        # 命中区域名
    restrictions = []       # 命中的限制规则

    # 遍历每个管制区域，判断"点是否在区域内"
    for zone in zones:
        boundary = zone.get("boundary", [])  # 区域的边界（多边形顶点列表）
        if len(boundary) < 3:
            continue  # 至少 3 个点才能围成区域，跳过无效数据

        # 判断点是否在多边形内
        inside = False
        if HAS_SHAPELY:
            # Shapely 写法：把顶点列表构造为 Polygon，用 .contains 判断
            polygon = Polygon(boundary)
            inside = polygon.contains(point)
        else:
            # 没用 Shapely 时的简化实现 — 用"射线法"手写
            # 这是一个经典算法，下面单独解释
            inside = _point_in_polygon_simple(lon, lat, boundary)

        if inside:
            # 命中！记录区域名和限制规则
            found_zones.append(zone["name"])
            restr = zone.get("restrictions", {})

            # 组装"人类可读"的限制描述
            limits = []
            if restr.get("entry_allowed") is False:
                limits.append("禁止进入")
            if restr.get("fishing_allowed") is False:
                limits.append("禁止捕捞")
            if restr.get("max_speed_knots") is not None:
                limits.append(f"限速 {restr['max_speed_knots']} 节")

            # 检查时间规则 — 比如禁渔期是 5月1日 - 9月1日
            time_rules = zone.get("time_rules", [])
            # datetime.utcnow() 拿当前 UTC 时间
            now = datetime.utcnow()
            for rule in time_rules:
                if rule.get("type") == "season":  # 只处理"季节性"规则
                    start_m, start_d = rule["start_month"], rule["start_day"]
                    end_m, end_d = rule["end_month"], rule["end_day"]
                    # 简化为"只看月日" — 不关心具体年份
                    current = (now.month, now.day)
                    start = (start_m, start_d)
                    end = (end_m, end_d)
                    # 两种情况：
                    #   1. 起止在同一年内 (start <= current <= end)
                    #   2. 跨年 (start > end，比如 11月-次年2月)
                    if start <= current <= end or (
                        start > end and (current >= start or current <= end)
                    ):
                        limits.append(rule.get("description", ""))

            restrictions.append({
                "zone": zone["name"],
                "type": zone.get("type", "unknown"),
                "limits": [l for l in limits if l],  # 列表推导式，去掉空字符串
            })

    return {
        "in_zones": found_zones,
        "restrictions": restrictions,
        "is_restricted": len(found_zones) > 0
    }


def _point_in_polygon_simple(px: float, py: float,
                              polygon: list) -> bool:
    """射线法（Ray Casting Algorithm）判断点是否在多边形内

    核心思想:
        从目标点 P 出发，向右画一条水平射线，
        统计这条射线和多边形边的交点个数。
        - 奇数个交点 → P 在多边形内
        - 偶数个交点 → P 在多边形外

    直观理解:
        想象你站在 P 点，向右走；每穿过一条边，就是进入或走出多边形。
        走了奇数次墙，最终一定"在里面"。

    Args:
        px, py: 目标点的 x, y 坐标（这里 x=经度, y=纬度）
        polygon: 多边形顶点列表，[[x1,y1], [x2,y2], ...]

    Returns:
        bool: True 表示点在多边形内

    【算法复杂度】 O(n)，n 是多边形顶点数。每条边检查一次。
    """
    inside = False
    n = len(polygon)
    for i in range(n):
        # 取当前边 (i → i+1)，最后一条边连回起点 (n-1 → 0)
        # 取模 % n 让最后一条边能"绕回"起点
        x1, y1 = polygon[i]
        x2, y2 = polygon[(i + 1) % n]

        # 关键判断: 这条边是否"穿过"目标点 y 所在的水平线
        # (y1 > py) != (y2 > py) 表示 y1 和 y2 分布在 py 两侧
        if ((y1 > py) != (y2 > py)):
            # 用线性插值求交点的 x 坐标:
            #   过 P 点向右的水平线 y=py, 和边 (x1,y1)→(x2,y2) 的交点
            #   公式推导: y1 + t*(y2-y1) = py  →  t = (py-y1)/(y2-y1)
            #            x = x1 + t*(x2-x1)
            x_intersect = x1 + (py - y1) * (x2 - x1) / (y2 - y1)
            # 如果交点在 P 的右边 (px < x_intersect)，记为一次穿越
            if px < x_intersect:
                inside = not inside  # 翻转 inside 状态
    return inside


# 工具 2: 速度分析

@tool
def speed_analysis(
    mmsi: str,
    current_speed: float,
    history: list,
    zone_speed_limit: Optional[float] = None
) -> dict:
    """分析船舶航速是否异常。

    检查项:
    - 是否超过所在区域的限速
    - 当前速度与历史平均速度是否显著偏离
    - 是否出现"突然降到极低速"这种捕捞行为特征

    Args:
        mmsi: 船舶 MMSI
        current_speed: 当前航速（节）
        history: 历史轨迹点列表，每个元素需包含 speed 字段
        zone_speed_limit: 当前区域的限速值（节），无限制则为 None

    Returns:
        dict: {
            "is_violation": bool,
            "avg_speed": float,
            "max_speed": float,
            "speed_change_ratio": float,
            "analysis": str
        }
    """
    # 从历史数据里提取所有速度值
    speeds = []
    for point in history:
        s = point.get("speed")
        # isinstance(s, (int, float)) 既允许 int 也允许 float
        if s is not None and isinstance(s, (int, float)):
            speeds.append(float(s))

    # 没有历史数据时 — 没法对比
    if not speeds:
        return {
            "is_violation": False,
            "avg_speed": current_speed,
            "max_speed": current_speed,
            "speed_change_ratio": 0,
            "analysis": "无历史数据，无法分析速度趋势",
        }

    # 基础统计
    avg_speed = sum(speeds) / len(speeds)   # 平均速度
    max_speed = max(speeds)                 # 历史最高速度

    # 检查 1: 当前速度是否超过区域限速
    over_speed = False
    if zone_speed_limit and current_speed > zone_speed_limit:
        over_speed = True

    # 检查 2: 当前速度与平均速度的变化幅度
    # 公式: |current - avg| / avg = 变化率（相对值，避免绝对值受单位影响）
    speed_change = 0
    if avg_speed > 0:  # 防止除零
        speed_change = abs(current_speed - avg_speed) / avg_speed

    # 阈值: 变化率超过 30% 视为异常（来自 THRESHOLDS 配置）
    is_anomaly = speed_change > THRESHOLDS["speed_anomaly_ratio"]

    # 综合判断
    violations = []
    if over_speed:
        violations.append(
            f"超速: 当前 {current_speed} 节 > 限速 {zone_speed_limit} 节"
        )
    # 经验规则: 从高速骤降到低速(<3节) — 高度疑似"放网捕捞"
    if is_anomaly and current_speed < 3 and avg_speed > 8:
        violations.append(
            f"速度骤降: 从平均 {avg_speed:.1f} 节降至 {current_speed} 节，"
            f"变化率 {speed_change:.0%}，疑似开始作业"
        )

    return {
        "is_violation": len(violations) > 0,
        "is_over_speed": over_speed,
        "avg_speed": round(avg_speed, 2),     # round(x, 2) 保留 2 位小数
        "max_speed": round(max_speed, 2),
        "current_speed": current_speed,
        "speed_change_ratio": round(speed_change, 2),
        "violations": violations,
        "analysis": "; ".join(violations) if violations else "速度正常",
    }


# 工具 3: 轨迹异常分析

@tool
def trajectory_analysis(
    mmsi: str,
    history: list,
    current_position: dict
) -> dict:
    """分析船舶历史轨迹中的异常行为。

    检查项:
    - AIS 信号长时间丢失（船故意关机逃逸？）
    - 航向异常突变（不可能 90° 急转，除非是数据错误或恶意行为）

    Args:
        mmsi: 船舶 MMSI
        history: 历史轨迹点列表
        current_position: 当前位置字典

    Returns:
        dict: 异常检测结果
    """
    anomalies = []  # 收集所有异常

    # 检查 AIS 信号连续性
    # 把"历史"和"当前"拼成完整时间序列
    all_points = history + [current_position]
    timestamps = []
    for p in all_points:
        ts = p.get("timestamp")
        if ts:
            try:
                # fromisoformat 解析 ISO 时间格式
                # .replace("Z", "+00:00") 是把 UTC 标记 Z 替换为 +00:00
                # Python 的 fromisoformat 早期版本不认 Z
                timestamps.append(datetime.fromisoformat(
                    ts.replace("Z", "+00:00")
                ))
            except (ValueError, AttributeError):
                # 时间戳格式错误就跳过这个点
                continue

    if len(timestamps) >= 2:
        timestamps.sort()  # 按时间排序
        gaps = []
        for i in range(1, len(timestamps)):
            # (t2 - t1).total_seconds() 得到秒数
            gap_minutes = (timestamps[i] - timestamps[i-1]).total_seconds() / 60
            # 超过 30 分钟没信号视为异常（阈值来自配置）
            if gap_minutes > THRESHOLDS["ais_gap_minutes"]:
                gaps.append({
                    "from": timestamps[i-1].isoformat(),
                    "to": timestamps[i].isoformat(),
                    "gap_minutes": round(gap_minutes, 1),
                })

        if gaps:
            anomalies.append({
                "type": "ais_gap",
                "detail": f"发现 {len(gaps)} 处 AIS 信号缺失",
                "gaps": gaps,
            })

    # 检查航向突变
    # 提取所有航向值
    courses = []
    for p in all_points:
        c = p.get("course")
        if c is not None:
            courses.append(float(c))

    # 至少 3 个航向点才能检查突变
    if len(courses) >= 3:
        for i in range(1, len(courses)):
            # 航向差要"考虑环绕": 359° → 1° 实际只转了 2°, 不是 358°
            diff = abs(courses[i] - courses[i-1])
            if diff > 180:
                diff = 360 - diff  # 跨越 0° 时取补角
            # 航向突变超过 90 度 — 不可能是正常航行
            if diff > 90:
                anomalies.append({
                    "type": "course_anomaly",
                    "detail": f"航向在点 {i-1} 到 {i} 突变 {diff:.0f}°",
                })

    return {
        "has_anomaly": len(anomalies) > 0,
        "anomalies": anomalies,
        "total_points": len(all_points),
        "time_span_minutes": (
            (timestamps[-1] - timestamps[0]).total_seconds() / 60
            if len(timestamps) >= 2 else 0
        ),
    }


# 工具 4: 法规查询

@tool
def query_regulation(
    zone_name: str,
    ship_type: Optional[str] = None,
    time_info: Optional[str] = None
) -> dict:
    """查询特定区域/场景的适用法规。

    当需要知道"这个区域有什么规定"或"这种行为违反了什么"时调用。

    Args:
        zone_name: 区域名称，如 "禁渔区A"
        ship_type: 船舶类型（可选），如 "拖网渔船"
        time_info: 时间信息（可选），如 "禁渔期"

    Returns:
        dict: 适用法规列表
    """
    zones = REGULATIONS.get("zones", [])
    violation_types = REGULATIONS.get("violation_types", {})

    # 查找匹配的管制区域
    zone = None
    for z in zones:
        if z["name"] == zone_name:
            zone = z
            break  # 找到了就退出循环

    if not zone:
        return {
            "found": False,
            "message": f"未找到区域 '{zone_name}' 的规则",
            "regulations": [],
        }

    # 根据区域类型匹配违规类别
    zone_type = zone.get("type", "")
    matched_violations = []

    # 不同区域类型对应不同的违规类别
    if zone_type == "fishing_protected":
        vt = violation_types.get("illegal_fishing", {})
        matched_violations.append({
            "code": "illegal_fishing",
            "label": vt.get("label", "非法捕捞"),
            "description": vt.get("description", ""),
            "penalty": vt.get("penalty", ""),
            "auto_alert_threshold": vt.get("auto_alert_threshold", 0.85),
        })
    elif zone_type == "restricted":
        vt = violation_types.get("restricted_area_entry", {})
        matched_violations.append({
            "code": "restricted_area_entry",
            "label": vt.get("label", "禁航区入侵"),
            "description": vt.get("description", ""),
            "penalty": vt.get("penalty", ""),
            "auto_alert_threshold": vt.get("auto_alert_threshold", 0.9),
        })

    # 如果有限速配置，添加超速违规类别
    restr = zone.get("restrictions", {})
    if restr.get("max_speed_knots") is not None:
        vt = violation_types.get("speed_violation", {})
        matched_violations.append({
            "code": "speed_violation",
            "label": vt.get("label", "超速行驶"),
            "description": f"限速 {restr['max_speed_knots']} 节",
            "penalty": vt.get("penalty", ""),
            "auto_alert_threshold": vt.get("auto_alert_threshold", 0.9),
            "speed_limit": restr["max_speed_knots"],
        })

    return {
        "found": True,
        "zone_name": zone["name"],
        "zone_type": zone_type,
        "applicable_violations": matched_violations,
        "time_rules": zone.get("time_rules", []),
        "regulations": matched_violations,
    }


# 工具 5: 船舶注册信息查询

@tool
def ship_registry_lookup(mmsi: str) -> dict:
    """查询船舶注册信息。

    当需要了解船舶的基本信息（类型、尺寸、国籍等）时调用。
    实际生产中应该连接海事局的真实数据库，这里是模拟数据。

    Args:
        mmsi: 船舶 MMSI 编号（9位数字）

    Returns:
        dict: 船舶注册信息（如果找到的话）
    """
    # 模拟数据库 — 实际使用时替换为真实 API 调用
    _mock_registry = {
        "412345678": {
            "mmsi": "412345678",
            "name": "OCEAN-KING",
            "ship_type": "拖网渔船",
            "nationality": "中国",
            "length": 35.0,
            "width": 8.0,
            "gross_tonnage": 200,    # 总吨位
            "build_year": 2018,
            "status": "active",
        },
        "412345679": {
            "mmsi": "412345679",
            "name": "GLOBAL-TRADER",
            "ship_type": "集装箱船",
            "nationality": "中国",
            "length": 200.0,
            "width": 32.0,
            "gross_tonnage": 30000,
            "build_year": 2020,
            "status": "active",
        },
    }

    ship = _mock_registry.get(mmsi)
    if ship:
        return {"found": True, "ship_info": ship}
    else:
        return {
            "found": False,
            "ship_info": None,
            "message": f"未找到 MMSI '{mmsi}' 的注册信息"
        }


# 工具列表（集中导出，方便 agents.py 引用）

# 每个智能体只能看到"自己该看的工具"，实现权限隔离
RULE_ENGINE_TOOLS = [geo_fence_check, query_regulation]
TRAJECTORY_TOOLS = [speed_analysis, trajectory_analysis]
AIS_VALIDATOR_TOOLS = [ship_registry_lookup, trajectory_analysis]
ALL_TOOLS = RULE_ENGINE_TOOLS + TRAJECTORY_TOOLS + AIS_VALIDATOR_TOOLS
