"""
船舶违规检测智能体 — 数据文件处理器
=====================================

【这个文件做什么？】
  负责数据文件的读写转换：
  - 从 data/input/ 读 CSV 船舶数据 → 转成 ShipData 格式
  - 把分析结果存为 CSV → 输出到 data/output/

【支持的输入格式】
  1. 标准输入 CSV（推荐）— 每行一条船，含完整字段
  2. 原始 AIS CSV — AIS 原始数据格式，按 MMSI 自动分组

【输出格式】
  结果 CSV — 每行一条分析结果，含违规判定、置信度、风险等级等

【几个 Python 概念先补一下】
  1. csv.DictReader / csv.DictWriter
     → 按"列名"读/写 CSV，不用记列的顺序。DictReader 把每行读成 dict。
  2. csv.fieldnames
     → 读取或设置 CSV 的表头列名列表。
  3. yield
     → 关键字，把函数变成"生成器"。调用一次返回一个值，函数暂停；
       下次再调用，从暂停处继续。适合处理大文件，节省内存。
  4. lambda
     → 匿名函数。lambda x: x*2 等价于 def f(x): return x*2。
       常用于 sort(key=...) 等需要传"小函数"的地方。
  5. enumerate(iterable, start)
     → 遍历时同时给出"下标 + 元素"。比手动维护 i += 1 简洁。
  6. 列表切片 + 步长 [::step]
     → 从列表中均匀采样。例: [::2] 表示每隔一个取一个。
"""

import csv            # CSV 文件读写
import json           # JSON 解析
import os             # 操作系统接口
from datetime import datetime
from pathlib import Path
from typing import Generator, List, Optional

from loguru import logger


# 字段映射常量

# 原始 AIS CSV 的列名（用于读取已有的大 CSV 文件，如 fzais1001.csv）
RAW_AIS_FIELDS = [
    "mmsi", "time", "speed", "course", "heading",
    "lon", "lat", "sub_mmsi", "geom", "id"
]

# 标准输入 CSV 的列名（推荐使用）
# 每条船一行，历史轨迹以 JSON 数组形式放在 history_json 字段
STANDARD_INPUT_FIELDS = [
    # 船舶基本信息
    "mmsi",               # 9位MMSI编号
    "name",               # 船名
    "ship_type",          # 船舶类型（如"拖网渔船"、"集装箱船"）
    "length",             # 船长（米，可选）
    "width",              # 船宽（米，可选）
    # 当前位置
    "lat",                # 纬度
    "lon",                # 经度
    "speed",              # 航速（节）
    "course",             # 航向（度）
    "timestamp",          # UTC 时间戳
    "status",             # 航行状态（可选）
    # 上下文
    "current_zone",       # 当前所在管制区域
    "time_info",          # 时间信息（如"禁渔期"）
    # 历史轨迹（可选）
    # history_json 是 JSON 数组字符串，每个元素须含 lat, lon, speed, course, timestamp
    # 示例: [{"lat": 38.08, "lon": 121.48, "speed": 11.2, "course": 135.0, "timestamp": "2026-07-11T06:00:00Z"}]
    "history_json",
]

# 输出结果 CSV 的列名（按这个顺序写入）
OUTPUT_FIELDS = [
    "mmsi",               # 船舶 MMSI
    "name",               # 船名
    "ship_type",          # 船舶类型
    "analysis_time",      # 分析时间
    "violation_detected", # 是否违规 (True/False)
    "violation_type",     # 违规类型代码
    "violation_label",    # 违规中文描述
    "confidence",         # 置信度 (0~1)
    "risk_level",         # 风险等级: high/middle/low
    "recommended_action", # 建议操作
    "final_assessment",   # 综合判定说明
    "evidence_summary",   # 证据链摘要（简略）
    "errors",             # 错误信息
]


# 1. 读取标准输入 CSV

def read_standard_csv(filepath: str) -> List[dict]:
    """读取标准格式的输入 CSV → 返回 ShipData 格式的字典列表

    标准 CSV 每行一条船，包含船舶信息、当前位置、上下文。
    历史轨迹用 history_json 字段存储 JSON 数组。

    Args:
        filepath: CSV 文件路径

    Returns:
        list[dict]: 每条船的数据，符合 ShipData 格式

    示例 CSV:
        mmsi,name,ship_type,lat,lon,speed,course,timestamp,status,current_zone,time_info,history_json
        412345678,OCEAN-KING,拖网渔船,38.1234,121.5678,0.8,180.0,2026-07-11T08:30:00Z,fishing,禁渔区A,禁渔期(5月-9月),"[{...}]"
    """
    filepath = Path(filepath)
    if not filepath.exists():
        logger.error(f"文件不存在: {filepath}")
        return []

    ships_data = []
    logger.info(f"正在读取标准输入 CSV: {filepath}")

    # encoding="utf-8-sig": -sig 表示自动去掉文件开头的 BOM（如果有）
    # 很多 Windows 工具导出 CSV 时会带 BOM, 不去掉会导致第一列名变 "\ufeffxxx"
    with open(filepath, "r", encoding="utf-8-sig") as f:
        # DictReader 把每一行读成 dict, 键是表头
        reader = csv.DictReader(f)
        # 去除列名首尾空格（防御性编程：数据来源不可控）
        reader.fieldnames = [fn.strip().lower() for fn in reader.fieldnames]

        row_count = 0
        for row in reader:
            row_count += 1
            try:
                # 调用辅助函数把一行转成 ShipData 格式
                ship_data = _row_to_ship_data(row)
                ships_data.append(ship_data)
            except Exception as e:
                # 一行出错不要让整个文件读失败 — 记录后跳过
                logger.warning(f"第 {row_count} 行解析失败: {e}")
                continue

    logger.info(f"成功读取 {len(ships_data)} 条船舶数据 (共 {row_count} 行)")
    return ships_data


def _row_to_ship_data(row: dict) -> dict:
    """将 CSV 的一行转换为 ShipData 格式的字典"""
    # 船舶基本信息
    ship_info = {
        "mmsi": str(row.get("mmsi", "")).strip(),
        "name": str(row.get("name", "")).strip() or None,   # 空字符串变 None
        "ship_type": str(row.get("ship_type", "")).strip() or None,
    }
    # 可选数值字段：只有当值非空且能转 float 时才填
    for opt_field in ["length", "width"]:
        val = row.get(opt_field, "")
        if val:
            try:
                ship_info[opt_field] = float(val)
            except ValueError:
                pass  # 转换失败就跳过这个字段

    # 当前位置（这些是必填的，但用 float() 转换可能失败，留给上层校验）
    current_pos = {
        "lat": float(row.get("lat", 0)),
        "lon": float(row.get("lon", 0)),
        "speed": float(row.get("speed", 0)),
        "course": float(row.get("course", 0)),
        "timestamp": str(row.get("timestamp", "")),
    }
    # 状态字段: 只有非空时才加（避免 None 触发 Pydantic 校验器无谓调用）
    status = row.get("status", "").strip()
    if status:
        current_pos["status"] = status

    # 上下文
    context = {}
    zone = row.get("current_zone", "").strip()
    if zone:
        context["current_zone"] = zone
    time_info = row.get("time_info", "").strip()
    if time_info:
        context["time_info"] = time_info

    # 历史轨迹（JSON 字符串 → Python 列表）
    history = []
    history_raw = row.get("history_json", "").strip()
    if history_raw:
        try:
            history = json.loads(history_raw)   # json.loads 把 JSON 字符串转成 Python 对象
            if not isinstance(history, list):   # 防御: 不是列表就当空
                history = []
        except json.JSONDecodeError as e:
            logger.warning(f"history_json 解析失败: {e}")

    return {
        "ship": ship_info,
        "current_position": current_pos,
        "history": history,
        "context": context,
    }


# 2. 读取原始 AIS CSV（按 MMSI 分组）

def read_raw_ais_csv(filepath: str, max_ships: Optional[int] = None) -> List[dict]:
    """读取原始 AIS 数据 CSV → 按 MMSI 分组 → 返回 ShipData 列表

    原始 AIS CSV 格式（如 fzais1001.csv）每行是一条 AIS 报告，
    同一条船有连续多行数据。本函数自动按 MMSI 分组，
    将最后一条作为当前位置，其余作为历史轨迹。

    Args:
        filepath: CSV 文件路径
        max_ships: 最多读取多少条船（None = 全部）

    Returns:
        list[dict]: 每条船的数据，符合 ShipData 格式

    注意:
        - 大文件（几十万行）处理较慢，建议先用 max_ships 限制
        - 原始 AIS 数据没有船名/类型，这些字段会留空
    """
    filepath = Path(filepath)
    if not filepath.exists():
        logger.error(f"文件不存在: {filepath}")
        return []

    logger.info(f"正在读取原始 AIS CSV: {filepath}")
    logger.info("正在按 MMSI 分组，这可能需要一些时间...")

    # 第一步: 按 MMSI 分组
    # dict: {mmsi: [point1, point2, ...]}
    ships_points = {}

    with open(filepath, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        reader.fieldnames = [fn.strip().lower() for fn in reader.fieldnames]

        line_count = 0
        for row in reader:
            line_count += 1
            mmsi = str(row.get("mmsi", "")).strip()

            if not mmsi:
                continue  # 没 MMSI 跳过

            # 控制数量: 已收集到 max_ships 个不同 MMSI, 就不再加新的
            if max_ships and mmsi not in ships_points and len(ships_points) >= max_ships:
                continue

            if mmsi not in ships_points:
                ships_points[mmsi] = []

            try:
                point = {
                    "lat": float(row.get("lat", 0)),
                    "lon": float(row.get("lon", 0)),
                    "speed": float(row.get("speed", 0)),
                    "course": float(row.get("course", 0)),
                    # 原始数据时间格式可能多样, 用辅助函数统一化
                    "timestamp": _normalize_timestamp(str(row.get("time", "")).strip()),
                }
                ships_points[mmsi].append(point)
            except (ValueError, TypeError) as e:
                # 一行解析失败就跳过，不要让整个文件读不了
                logger.debug(f"第 {line_count} 行解析跳过: {e}")
                continue

    logger.info(f"共读取 {line_count} 行 AIS 数据，发现 {len(ships_points)} 条船舶")

    # 第二步: 转换为 ShipData 格式
    ships_data = []
    for mmsi, points in ships_points.items():
        if len(points) < 1:
            continue

        # 按时间排序（保证历史轨迹是时间顺序）
        # key 是 lambda, 接收一个点 p, 返回用于排序的 key
        points.sort(key=lambda p: p.get("timestamp", ""))

        # 最新点作为当前位置, 其余作为历史
        current = points[-1]
        history = points[:-1]

        # 限制历史点数, 避免超出 LLM 上下文窗口
        MAX_HISTORY = 50
        if len(history) > MAX_HISTORY:
            # 均匀采样: 每隔 step 个点取 1 个
            # 例: 100 个点, MAX_HISTORY=50 → step=2, 取 0,2,4,...,98 共 50 个
            step = len(history) / MAX_HISTORY
            history = [history[int(i * step)] for i in range(MAX_HISTORY)]

        ship_data = {
            "ship": {
                "mmsi": mmsi,
                "name": None,
                "ship_type": None,
            },
            "current_position": current,
            "history": history,
            "context": {},   # 原始 AIS 没有上下文
        }
        ships_data.append(ship_data)

    logger.info(f"成功转换 {len(ships_data)} 条船舶数据")
    return ships_data


def _normalize_timestamp(ts: str) -> str:
    """统一时间戳格式为 ISO 8601

    原始数据中的时间格式可能是 "1/10/2022 20:28:10" (M/D/Y H:M:S)
    需要转为 ISO 格式 "2022-01-10T20:28:10Z" — 后续 Pydantic 才能解析。

    Args:
        ts: 原始时间字符串

    Returns:
        str: 归一化后的 ISO 格式字符串（解析失败则原样返回）
    """
    if not ts:
        return ""

    # 已经是 ISO 格式 (含 T 或 -), 直接返回
    if "T" in ts or ts.count("-") >= 2:
        return ts

    # 尝试各种已知格式
    for fmt in [
        "%Y%m%d%H%M%S",      # 紧凑格式: 20210728092829
        "%m/%d/%Y %H:%M:%S",  # 美式: 1/10/2022 20:28:10
        "%m/%d/%Y %H:%M",     # 省略秒
        "%Y-%m-%d %H:%M:%S",  # 标准格式
        "%Y/%m/%d %H:%M:%S",  # 斜杠分隔
    ]:
        try:
            # strptime = "string parse time" — 按指定格式把字符串解析为 datetime
            dt = datetime.strptime(ts, fmt)
            # strftime = "string format time" — 把 datetime 格式化为字符串
            return dt.strftime("%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            continue  # 这个格式不匹配, 试下一个

    # 所有格式都失败, 原样返回（让上层处理）
    logger.warning(f"无法解析时间戳: {ts}")
    return ts


# 3. 保存结果到 CSV

def save_results_to_csv(results: List[dict], filepath: str) -> str:
    """将分析结果列表保存为 CSV 文件

    Args:
        results: ShipViolationDetector.analyze() 返回的结果字典列表
        filepath: 输出文件路径

    Returns:
        str: 保存的文件路径
    """
    filepath = Path(filepath)
    # parents=True: 创建中间目录; exist_ok=True: 目录已存在不报错
    filepath.parent.mkdir(parents=True, exist_ok=True)

    logger.info(f"正在保存结果到: {filepath}")

    # newline="": Windows 下避免空行 (Python 文档明确建议)
    with open(filepath, "w", encoding="utf-8-sig", newline="") as f:
        # DictWriter 需要指定 fieldnames, 按这个顺序写列
        writer = csv.DictWriter(f, fieldnames=OUTPUT_FIELDS)
        writer.writeheader()   # 写入表头

        for result in results:
            row = _result_to_csv_row(result)
            writer.writerow(row)

    logger.info(f"结果已保存: {filepath} ({len(results)} 条记录)")
    return str(filepath)


def _result_to_csv_row(result: dict) -> dict:
    """将分析结果字典转换为 CSV 行字典

    主要工作: 把嵌套的 evidence_chain 拍平成一个简短字符串,
    否则写 CSV 会很乱。
    """
    # 证据链摘要
    evidence = result.get("evidence_chain", [])
    if evidence:
        summaries = []
        for ev in evidence:
            finding = ev.get("finding", "")
            # 截断过长文本, 避免单个单元格内容过多
            if len(str(finding)) > 80:
                finding = str(finding)[:77] + "..."
            summaries.append(f"[{ev.get('agent_name', '?')}] {finding}")
        # " | " 作为多条证据的分隔符
        evidence_summary = " | ".join(summaries)
    else:
        evidence_summary = ""

    # 错误信息: list 转 str
    errors = result.get("errors", [])
    errors_str = "; ".join(errors) if errors else ""

    return {
        "mmsi": result.get("mmsi", ""),
        "name": result.get("ship_name", ""),
        "ship_type": result.get("ship_type", ""),
        "analysis_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "violation_detected": str(result.get("violation_detected", False)),
        "violation_type": result.get("violation_type", "") or "",
        "violation_label": result.get("violation_label", "") or "",
        "confidence": f"{result.get('confidence', 0):.4f}",  # 4 位小数
        "risk_level": result.get("risk_level", "low"),
        "recommended_action": result.get("recommended_action", "monitor"),
        "final_assessment": (result.get("final_assessment", "") or ""),
        "evidence_summary": evidence_summary,
        "errors": errors_str,
    }


# 4. 智能文件检测与批量处理

def detect_csv_format(filepath: str) -> str:
    """自动检测 CSV 文件的格式类型

    通过检查表头列名来判断是标准格式还是原始 AIS 格式。
    这种"嗅探"机制让用户不用手动指定格式。

    Args:
        filepath: CSV 文件路径

    Returns:
        str: "standard" | "raw_ais" | "unknown"
    """
    filepath = Path(filepath)
    if not filepath.exists():
        return "unknown"

    with open(filepath, "r", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        try:
            # 只读第一行（表头）就退出
            header = [h.strip().lower() for h in next(reader)]
        except StopIteration:
            return "unknown"  # 文件是空的

    # 判断标准格式：必须含 name 和 current_zone
    standard_keys = {"name", "current_zone"}
    if standard_keys.issubset(set(header)):
        return "standard"

    # 判断原始 AIS 格式：含特定字段
    if "mmsi" in header and "time" in header and "geom" in header:
        return "raw_ais"

    # 兜底: 含基本字段也视为原始 AIS
    basic_ais = {"mmsi", "lat", "lon", "speed"}
    if basic_ais.issubset(set(header)):
        return "raw_ais"

    return "unknown"


def load_all_ships_from_csv(filepath: str, max_ships: Optional[int] = None) -> List[dict]:
    """自动检测 CSV 格式并读取船舶数据 — 统一入口

    无论标准格式还是原始 AIS 格式, 都能正确读取。

    Args:
        filepath: CSV 文件路径
        max_ships: 最多读取多少条船（仅对原始 AIS 格式有效）

    Returns:
        list[dict]: ShipData 格式的船舶数据列表
    """
    fmt = detect_csv_format(filepath)
    logger.info(f"检测到 CSV 格式: {fmt}")

    if fmt == "standard":
        return read_standard_csv(filepath)
    elif fmt == "raw_ais":
        return read_raw_ais_csv(filepath, max_ships)
    else:
        logger.error(f"无法识别的 CSV 格式: {filepath}")
        logger.error("支持两种格式:")
        logger.error("  1. 标准格式 — 含 mmsi, name, ship_type, lat, lon, speed, course, timestamp, current_zone 等列")
        logger.error("  2. 原始 AIS — 含 mmsi, time, lat, lon, speed, course 等列")
        return []


def list_input_csvs(input_dir: str) -> List[Path]:
    """列出输入目录中的所有 CSV 文件

    Args:
        input_dir: 输入目录路径

    Returns:
        list[Path]: CSV 文件路径列表
    """
    input_path = Path(input_dir)
    if not input_path.exists():
        logger.warning(f"输入目录不存在: {input_dir}")
        return []

    # sorted() 让文件按名字有序, 多次运行顺序一致, 便于调试
    csv_files = sorted(input_path.glob("*.csv"))
    if not csv_files:
        logger.warning(f"输入目录中没有 CSV 文件: {input_dir}")
    else:
        logger.info(f"发现 {len(csv_files)} 个 CSV 文件")

    return csv_files


def batch_process_directory(
    input_dir: str,
    output_dir: str,
    detector,
    max_ships_per_file: Optional[int] = None,
) -> List[str]:
    """批量处理输入目录中的所有 CSV 文件

    对每个文件:
    1. 自动检测格式并读取
    2. 逐条分析
    3. 保存结果到输出目录

    Args:
        input_dir: 输入目录路径
        output_dir: 输出目录路径
        detector: ShipViolationDetector 实例
        max_ships_per_file: 每个文件最多处理多少条船

    Returns:
        list[str]: 生成的结果文件路径列表
    """
    input_dir = Path(input_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    csv_files = list_input_csvs(input_dir)
    if not csv_files:
        return []

    result_files = []

    for csv_file in csv_files:
        logger.info(f"\n{'='*60}")
        logger.info(f"处理文件: {csv_file.name}")
        logger.info(f"{'='*60}")

        # 读取
        ships_data = load_all_ships_from_csv(str(csv_file), max_ships_per_file)
        if not ships_data:
            logger.warning(f"  文件中没有有效船舶数据，跳过")
            continue

        logger.info(f"  共 {len(ships_data)} 条船舶待分析")

        # 逐条分析
        all_results = []
        # enumerate(start=1): 下标从 1 开始, 符合"第1条"的人类习惯
        for i, ship_data in enumerate(ships_data, 1):
            mmsi = ship_data.get("ship", {}).get("mmsi", "unknown")
            name = ship_data.get("ship", {}).get("name", "")
            logger.info(f"  [{i}/{len(ships_data)}] 分析船舶: {name or mmsi}")

            try:
                result = detector.analyze(ship_data)

                # 补充船舶标识信息到结果中, 这样写 CSV 时能带上
                result["mmsi"] = mmsi
                result["ship_name"] = name or ""
                result["ship_type"] = ship_data.get("ship", {}).get("ship_type", "") or ""

                all_results.append(result)

            except Exception as e:
                # 单条船失败不阻塞整批
                logger.error(f"  船舶 {mmsi} 分析失败: {e}")
                all_results.append({
                    "mmsi": mmsi,
                    "ship_name": name or "",
                    "ship_type": ship_data.get("ship", {}).get("ship_type", "") or "",
                    "violation_detected": False,
                    "confidence": 0.0,
                    "risk_level": "low",
                    "recommended_action": "monitor",
                    "final_assessment": f"分析异常: {str(e)}",
                    "evidence_chain": [],
                    "errors": [f"分析异常: {str(e)}"],
                })

        # 保存结果
        if all_results:
            output_filename = f"results_{csv_file.stem}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            output_path = str(output_dir / output_filename)
            saved_path = save_results_to_csv(all_results, output_path)
            result_files.append(saved_path)

    return result_files
