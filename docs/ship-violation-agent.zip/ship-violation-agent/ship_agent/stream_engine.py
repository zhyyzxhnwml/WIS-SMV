"""
船舶违规检测 — 流式处理引擎
=============================

【这个文件做什么？】
  实现实时 AIS 数据流的处理引擎。
  每来一条 AIS 消息，做 O(1) 纯规则判断，仅在触发事件时才调 LLM 深度分析。

【架构】
  ┌──────────────┐    ┌────────────────────┐    ┌──────────────────┐
  │ AIS 消息到达  │───▶│  Per-Ship 状态管理器 │───▶│  事件触发引擎     │
  │ (单条dict)    │    │  dict[MMSI→Deque]  │    │  (纯规则判断)    │
  └──────────────┘    └────────────────────┘    └────────┬─────────┘
                                                         │
                                               ┌─────────▼─────────┐
                                               │ LLM 分析队列       │
                                               │ (异步，优先级排序)  │
                                               │ ThreadPoolExecutor │
                                               └───────────────────┘

【核心概念】
  滑动窗口: 每条船只保留最近 N 个位置点，节省内存。
  事件触发: 纯规则判断（区域/速度/轨迹/AIS 信号），不进 LLM。
  去重: 同一条船触发事件后标记 pending，分析完成前不再重复触发。
"""

import json
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Optional

from loguru import logger

from ship_agent.tools import (
    geo_fence_check,
    speed_analysis,
    trajectory_analysis,
)
from ship_agent.models import ViolationResult


class ShipStreamTracker:
    """单条船舶的流状态跟踪器

    维护一条船的滑动窗口历史位置，每次收到新位置时运行事件触发检查。
    """

    def __init__(self, mmsi: str, max_history: int = 50):
        """
        Args:
            mmsi: 船舶 MMSI
            max_history: 最多保留的历史点数（滑动窗口大小）
        """
        self.mmsi = mmsi
        self.positions = deque(maxlen=max_history)
        self.last_trigger_time: Optional[datetime] = None
        self.llm_analysis_pending = False
        self.total_messages = 0

    def add_position(self, pos: dict) -> Optional[dict]:
        """添加一个 AIS 位置点，运行触发检查

        Args:
            pos: AIS 位置点，须含 lat, lon, speed, course, timestamp

        Returns:
            None: 无异常，继续监控
            dict: 触发事件详情（含事件类型和描述）
        """
        self.positions.append(pos)
        self.total_messages += 1
        return self._check_triggers()

    def _check_triggers(self) -> Optional[dict]:
        """纯规则事件触发检查，0 LLM 调用

        检查项:
        - 1. 进入管制区域（地理围栏）
        - 2. 速度骤降（疑似捕捞/异常）
        - 3. AIS 信号长时间丢失
        - 4. 航向突变

        Returns:
            None 或事件详情 dict
        """
        if len(self.positions) < 2:
            return None  # 点数太少，无法判断

        current = self.positions[-1]

        # ── 检查 1: 地理围栏 ──
        geo_result = geo_fence_check(
            lat=current.get("lat", 0),
            lon=current.get("lon", 0),
        )
        if geo_result.get("is_restricted"):
            zones = geo_result.get("in_zones", [])
            # 避免反复触发同一个区域
            return {
                "type": "zone_entry",
                "severity": "high",
                "message": f"进入管制区域: {', '.join(zones)}",
                "detail": geo_result,
            }

        # ── 检查 2: 速度骤降 ──
        history_list = list(self.positions)[:-1]  # 除当前位置外的历史
        speed_result = speed_analysis(
            mmsi=self.mmsi,
            current_speed=current.get("speed", 0),
            history=history_list,
        )
        if speed_result.get("is_violation"):
            violations = speed_result.get("violations", [])
            return {
                "type": "speed_anomaly",
                "severity": "medium",
                "message": "; ".join(violations),
                "detail": speed_result,
            }

        # ── 检查 3 & 4: 轨迹异常（AIS 信号丢失 + 航向突变） ──
        traj_result = trajectory_analysis(
            mmsi=self.mmsi,
            history=history_list,
            current_position=current,
        )
        if traj_result.get("has_anomaly"):
            anomalies = traj_result.get("anomalies", [])
            return {
                "type": "trajectory_anomaly",
                "severity": "medium",
                "message": f"轨迹异常: {len(anomalies)} 处",
                "detail": traj_result,
            }

        return None  # 一切正常

    def build_ship_data(self) -> dict:
        """将当前跟踪状态构建为 ShipData 格式，供 LLM 分析使用

        Returns:
            dict: 符合 ShipData 结构的字典
        """
        positions = list(self.positions)
        current = positions[-1] if positions else {}
        history = positions[:-1] if len(positions) > 1 else []

        return {
            "ship": {
                "mmsi": self.mmsi,
                "name": None,
                "ship_type": None,
            },
            "current_position": current,
            "history": history,
            "context": {
                "current_zone": "实时流数据",
                "time_info": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
            },
        }


class StreamProcessor:
    """流式处理引擎主类

    管理所有船舶的状态跟踪器，处理单条 AIS 消息的事件触发和 LLM 分析调度。

    使用方式:
        processor = StreamProcessor(llm)
        for msg in ais_message_stream:
            event = processor.process_message(msg)
            if event:
                print(f"事件触发: {event['message']}")
    """

    def __init__(self, llm, max_workers: int = 2, max_history: int = 50):
        """
        Args:
            llm: LangChain LLM 实例
            max_workers: LLM 分析并行数
            max_history: 每条船最多保留的历史点数
        """
        from ship_agent.agents import ShipViolationDetector

        self.trackers: dict[str, ShipStreamTracker] = {}
        self.detector = ShipViolationDetector(llm)
        self.max_history = max_history
        self.event_log: list[dict] = []
        self.analysis_results: list[dict] = []
        self._executor = ThreadPoolExecutor(max_workers=max_workers)

    def process_message(self, msg: dict) -> Optional[dict]:
        """处理单条 AIS 消息

        步骤:
        1. 提取 MMSI，获取或创建船舶跟踪器
        2. 添加位置点，运行事件触发检查
        3. 如果触发事件且未在分析中，异步提交 LLM 深度分析

        Args:
            msg: AIS 消息字典。支持两种格式:
                - 标准: {"mmsi": "...", "lat": ..., "lon": ..., "speed": ..., "course": ..., "time": "..."}
                - 字段名带大写: {"MMSI": "...", "LAT": ..., ...}

        Returns:
            None: 无事件触发
            dict: 触发事件详情（含 type, severity, message）
        """
        # 字段名大小写兼容
        mmsi = str(
            msg.get("mmsi") or msg.get("MMSI") or ""
        ).strip()

        if not mmsi:
            return None

        # 构建标准位置点
        pos = {
            "lat": float(msg.get("lat") or msg.get("LAT") or 0),
            "lon": float(msg.get("lon") or msg.get("LON") or 0),
            "speed": float(msg.get("speed") or msg.get("SPEED") or 0),
            "course": float(msg.get("course") or msg.get("COURSE") or 0),
            "timestamp": str(
                msg.get("time") or msg.get("TIME") or msg.get("timestamp") or ""
            ),
        }

        # 获取或创建跟踪器
        if mmsi not in self.trackers:
            self.trackers[mmsi] = ShipStreamTracker(
                mmsi, max_history=self.max_history
            )
            logger.info(f"🆕 新船舶加入监控: {mmsi}")

        tracker = self.trackers[mmsi]

        # 运行事件触发检查
        event = tracker.add_position(pos)

        if event and not tracker.llm_analysis_pending:
            # 标记分析进行中，避免重复触发
            tracker.llm_analysis_pending = True
            self.event_log.append({
                "mmsi": mmsi,
                "time": datetime.utcnow().isoformat(),
                **event,
            })

            logger.info(
                f"🚨 [{mmsi}] 事件触发: {event['message']} "
                f"(severity={event['severity']})"
            )

            # 异步提交 LLM 深度分析
            ship_data = tracker.build_ship_data()
            future = self._executor.submit(
                self._run_analysis, mmsi, ship_data, tracker
            )
            # 添加回调，分析完成后释放 pending 状态
            future.add_done_callback(
                lambda f: self._on_analysis_done(mmsi, f)
            )

            return event

        return None  # 无事件

    def _run_analysis(
        self, mmsi: str, ship_data: dict, tracker: ShipStreamTracker
    ) -> dict:
        """在后台线程中执行 LLM 深度分析"""
        logger.info(f"🔍 [{mmsi}] 开始 LLM 深度分析...")
        try:
            result = self.detector.analyze(ship_data)
            result["mmsi"] = mmsi
            self.analysis_results.append(result)
            logger.info(
                f"✅ [{mmsi}] 深度分析完成: "
                f"{'违规' if result.get('violation_detected') else '正常'}"
            )
            return result
        except Exception as e:
            logger.error(f"❌ [{mmsi}] 深度分析异常: {e}")
            result = ViolationResult(
                violation_detected=False,
                final_assessment=f"流分析异常: {str(e)}",
                errors=[f"分析异常: {str(e)}"],
            ).model_dump()
            result["mmsi"] = mmsi
            self.analysis_results.append(result)
            return result

    def _on_analysis_done(self, mmsi: str, future):
        """LLM 分析完成后的回调 — 释放 pending 状态"""
        tracker = self.trackers.get(mmsi)
        if tracker:
            tracker.llm_analysis_pending = False
            logger.info(f"🔓 [{mmsi}] 分析完成，解除 pending 状态")

    def get_stats(self) -> dict:
        """获取当前处理统计"""
        return {
            "tracked_ships": len(self.trackers),
            "total_messages": sum(
                t.total_messages for t in self.trackers.values()
            ),
            "events_triggered": len(self.event_log),
            "analyses_completed": len(self.analysis_results),
        }

    def get_violations(self) -> list[dict]:
        """获取所有检测到的违规结果"""
        return [
            r for r in self.analysis_results
            if r.get("violation_detected")
        ]

    def shutdown(self):
        """关闭线程池，释放资源"""
        self._executor.shutdown(wait=True)
        logger.info("流处理引擎已关闭")


def run_stream_from_csv(
    csv_path: str,
    llm,
    max_ships: int = 0,
    max_workers: int = 2,
    delay_per_row: float = 0,
):
    """从 CSV 文件模拟 AIS 实时数据流

    按行读取 CSV，模拟 AIS 消息逐个到达，用于测试流式处理引擎。

    Args:
        csv_path: CSV 文件路径
        llm: LangChain LLM 实例
        max_ships: 最多监控多少条船（0 = 不限）
        delay_per_row: 每行之间的模拟延迟秒数
    """
    import csv
    import time
    from pathlib import Path

    csv_path = Path(csv_path)
    if not csv_path.exists():
        logger.error(f"文件不存在: {csv_path}")
        return

    processor = StreamProcessor(llm, max_workers=max_workers)

    logger.info(f"📡 开始流式处理: {csv_path.name}")
    logger.info(f"   模拟延迟: {delay_per_row}秒/行" if delay_per_row else "   无延迟")

    # 读取 CSV
    with open(csv_path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        # 列名统一小写
        reader.fieldnames = [fn.strip().lower() for fn in reader.fieldnames]

        row_count = 0
        start_time = time.time()

        for row in reader:
            if max_ships > 0 and len(processor.trackers) >= max_ships:
                # 不处理新 MMSI，但已有 MMSI 继续接收
                mmsi = row.get("mmsi", "").strip()
                if mmsi and mmsi not in processor.trackers:
                    continue

            event = processor.process_message(row)
            if event:
                icon = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(
                    event.get("severity", "low"), "⚪"
                )
                print(f"{icon} [{event['type']}] {event['message']}")

            row_count += 1
            if row_count % 10000 == 0:
                elapsed = time.time() - start_time
                stats = processor.get_stats()
                logger.info(
                    f"⏱️  已处理 {row_count} 行 ({elapsed:.1f}s) — "
                    f"监控 {stats['tracked_ships']} 船, "
                    f"触发 {stats['events_triggered']} 事件, "
                    f"完成 {stats['analyses_completed']} 分析"
                )

            if delay_per_row > 0:
                time.sleep(delay_per_row)

    elapsed = time.time() - start_time
    stats = processor.get_stats()
    violations = processor.get_violations()

    print(f"\n{'═' * 60}")
    print(f"📊 流式处理完成")
    print(f"{'═' * 60}")
    print(f"   总处理行数:    {row_count}")
    print(f"   监控船舶数:    {stats['tracked_ships']}")
    print(f"   触发事件:      {stats['events_triggered']}")
    print(f"   完成分析:      {stats['analyses_completed']}")
    print(f"   发现违规:      {len(violations)} 艘")
    print(f"   耗时:          {elapsed:.1f}s")
    print(f"{'═' * 60}\n")

    processor.shutdown()
