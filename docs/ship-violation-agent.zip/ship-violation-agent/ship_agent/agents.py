"""
船舶违规检测智能体 — 智能体定义 + 主流程编排
===============================================

【这个文件做什么？】
  整个系统的核心模块。采用"多智能体协作"架构:
    1. 规则引擎智能体 — 查区域/法规, 判断是否违规
    2. 轨迹分析智能体 — 看历史轨迹, 识别异常行为
    3. AIS 验证智能体 — 检查数据本身是否可信
    4. 主控智能体 (Orchestrator) — 综合上面三个, 给出最终判决

  ┌─────────────────────────────────────────────────┐
  │               OrchestratorAgent                  │
  │  主控智能体 - 负责任务分解、子智能体调度、综合判决  │
  ├──────────┬──────────┬──────────┬────────────────┤
  │          │          │          │                │
  ▼          ▼          ▼          ▼                │
┌──────┐ ┌────────┐ ┌────────┐ ┌────────────┐      │
│规则  │ │轨迹    │ │AIS     │ │证据链      │      │
│引擎  │ │分析    │ │验证    │ │整合        │      │
│智能体│ │智能体  │ │智能体  │ │智能体      │      │
└──────┘ └────────┘ └────────┘ └────────────┘      │

【LangChain 核心概念】
  create_react_agent(model, tools, prompt)
  → 创建一个 ReAct 模式的智能体
  → model: LLM 实例
  → tools: 该智能体可调用的工具列表
  → prompt: System Prompt（角色的灵魂!）

【LangGraph 核心概念】
  使用 StateGraph 编排多智能体工作流。
  - State: 全局共享状态（dict）
  - Node: 每个处理步骤是一个节点（函数）
  - Edge: 节点间的数据流向（决定执行顺序）

【闭包（Closure）模式】
  注意看 build_workflow() 函数内部的节点函数定义。
  这些函数"捕获"了外层作用域的 agent 变量 → 闭包。
  这样节点函数不需要通过 state 传递智能体实例,
  避免了"不可序列化"的问题（LLM 对象不能放 state 里）。

【几个 Python 概念先补一下】
  1. TypedDict
     → 给字典加上"类型提示"。运行时跟普通 dict 没区别,
       但 IDE 能补全, 类型检查工具能验证。
       例: class S(TypedDict): a: int; b: str
  2. f-string 嵌套 dict 访问
     → f"{ship['mmsi']}" 等价于 ship['mmsi'] 然后格式化为字符串。
  3. defaultdict
     → 字典的子类, 访问不存在的键时返回默认值。
  4. setdefault(key, default)
     → dict.get 的"写"版本。键不存在时设默认值, 存在则返回当前值。
  5. 闭包 (Closure)
     → 内部函数"记住"创建它的外部函数的变量。
       def outer():
           x = 1
           def inner():
               print(x)   # inner 记住了 outer 的 x
           return inner
"""

import json
from typing import TypedDict, Optional

from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, START, END
from langgraph.prebuilt import create_react_agent
from loguru import logger

from ship_agent.models import ShipData, ViolationResult, AgentFinding
from ship_agent.tools import (
    RULE_ENGINE_TOOLS, TRAJECTORY_TOOLS, AIS_VALIDATOR_TOOLS,
    geo_fence_check, speed_analysis, trajectory_analysis,
)


# 1. System Prompts — 智能体的"灵魂"
#
# System Prompt 决定智能体的行为方式。
# 写 Prompt 的原则:
#   ① 明确角色 — "你是什么专家"
#   ② 明确任务 — "你要做什么"
#   ③ 明确约束 — "你不能做什么"
#   ④ 明确输出 — "输出什么格式"
#
# 注: 这些 Prompt 用中文, 因为 Qwen 中文能力强。
#    如果用英文模型（如 Llama），需要换成英文 Prompt。

RULE_AGENT_PROMPT = """你是船舶违规检测系统的规则引擎专家。
你的任务: 分析船舶位置/类型/时间, 判断是否违规。

你可用的工具:
1. geo_fence_check(lat, lon, ship_type) — 检查船舶在什么区域及区域限制
2. query_regulation(zone_name, ship_type, time_info) — 查询适用法规

分析步骤:
1. 先用 geo_fence_check 查船舶所在区域
2. 如果在管制区域, 用 query_regulation 查具体法规
3. 结合船舶类型和时间, 判断是否违规

严格按 JSON 格式输出（不要 markdown 包裹）:
{{
  "status": "合规/违规待确认/信息不足",
  "findings": ["发现1", "发现2"],
  "matched_violations": ["违规类型"],
  "confidence": 0.0-1.0
}}
"""

TRAJECTORY_AGENT_PROMPT = """你是船舶违规检测系统的轨迹分析专家。
你的任务: 分析历史轨迹, 识别异常行为模式。

你可用的工具:
1. speed_analysis(mmsi, current_speed, history, zone_speed_limit) — 速度分析
2. trajectory_analysis(mmsi, history, current_position) — 轨迹异常检测

关注的异常模式: 超速、速度骤降（疑似捕捞）、AIS信号丢失、航向突变

严格按 JSON 格式输出（不要 markdown 包裹）:
{{
  "status": "正常/异常待确认",
  "anomalies": ["异常描述"],
  "confidence": 0.0-1.0
}}
"""

AIS_AGENT_PROMPT = """你是船舶违规检测系统的AIS数据验证专家。
你的任务: 评估AIS数据可信度, 判断是否有伪造或异常。

你可用的工具:
1. ship_registry_lookup(mmsi) — 查船舶注册信息
2. trajectory_analysis(mmsi, history, current_position) — 查轨迹异常

重点关注: MMSI是否在注册库、轨迹是否合理、是否有信号缺失

严格按 JSON 格式输出（不要 markdown 包裹）:
{{
  "status": "数据可信/存在异常/不可信",
  "ais_quality": "good/fair/poor",
  "findings": ["发现"],
  "confidence": 0.0-1.0
}}
"""

ORCHESTRATOR_PROMPT = """你是一个船舶违规检测系统的总指挥智能体。
你的职责: 综合多个专家的分析结果, 做出最终违规判定。

你将收到三个专家的报告:
1. 规则引擎专家 — 判断是否违反区域/时间规则
2. 轨迹分析专家 — 判断轨迹是否异常
3. AIS验证专家 — 判断数据是否可信

综合判定的评分标准:
- confidence >= 0.85: 高风险 → auto_alert
- 0.60 <= confidence < 0.85: 中风险 → manual_review
- confidence < 0.60: 低风险 → monitor

要求: 客观分析, 不过度判罚, 数据不足时给低分。

严格按 JSON 格式输出（不要 markdown 包裹）:
{{
  "violation_detected": true/false,
  "violation_type": "违规代码",
  "violation_label": "违规中文描述",
  "confidence": 0.0-1.0,
  "risk_level": "high/middle/low",
  "evidence_chain": [
    {{"agent_name": "专家名", "finding": "发现", "confidence": 0.0}}
  ],
  "final_assessment": "综合判定说明",
  "recommended_action": "auto_alert/manual_review/monitor"
}}
"""


# 2. 智能体工厂函数
#
# 工厂模式: 用一个函数来创建智能体, 而不是直接 new。
# 好处: 创建逻辑统一管理, 切换模型时只需改一处。

def create_rule_agent(llm):
    """创建规则引擎智能体

    create_react_agent 是 LangGraph 提供的高级函数。
    它在内部创建了一个完整的 ReAct 循环图:
      收到消息 → 思考 → 调用工具 → 获取结果 → 再思考 → ...
      直到不再需要调用工具 → 输出最终回答

    Args:
        llm: LangChain LLM 实例
    Returns:
        CompiledStateGraph: 可调用的智能体对象
    """
    return create_react_agent(
        model=llm,
        tools=RULE_ENGINE_TOOLS,
        prompt=RULE_AGENT_PROMPT,
    )


def create_trajectory_agent(llm):
    """创建轨迹分析智能体"""
    return create_react_agent(
        model=llm,
        tools=TRAJECTORY_TOOLS,
        prompt=TRAJECTORY_AGENT_PROMPT,
    )


def create_ais_agent(llm):
    """创建AIS验证智能体"""
    return create_react_agent(
        model=llm,
        tools=AIS_VALIDATOR_TOOLS,
        prompt=AIS_AGENT_PROMPT,
    )


def create_orchestrator_agent(llm):
    """创建主控智能体（编排器）

    注意: 主控智能体不直接调用工具。
    它通过分析子智能体的返回来做综合判决。
    所以它的工具列表是空的。
    """
    return create_react_agent(
        model=llm,
        tools=[],
        prompt=ORCHESTRATOR_PROMPT,
    )


# 3. 工作流状态定义
#
# LangGraph 使用 TypedDict 定义状态。
# 每个节点可以读取和写入状态字段。
# 节点之间通过状态传递数据。

class ShipAnalysisState(TypedDict):
    """船舶分析工作流的状态

    这是 LangGraph 图（Graph）的全局状态。
    每个节点可以:
    - 读取已有字段
    - 写入新字段（或覆盖）
    """
    # 输入
    raw_input: dict                      # 原始输入数据

    # 中间结果（由各子智能体写入）
    rule_result: Optional[dict]          # 规则引擎分析结果
    trajectory_result: Optional[dict]    # 轨迹分析结果
    ais_result: Optional[dict]           # AIS验证结果

    # 最终输出
    final_result: Optional[dict]         # 综合判定结果

    # 错误记录
    errors: list[str]


# 4. 辅助函数

def _try_parse_json(text: str) -> dict:
    """尝试从 LLM 回复中提取 JSON

    LLM 有时候会在 JSON 外面加 markdown 包裹（```json ... ```）,
    或者加额外的文字。这个函数负责清理和提取。

    Args:
        text: LLM 的回复文本
    Returns:
        解析出的 dict, 失败则返回空 dict
    """
    if not text:
        return {}

    text = text.strip()  # 去首尾空白

    # 去掉 markdown 代码块包裹
    if text.startswith("```"):
        # 找第一个 { 和最后一个 }, 中间就是要的 JSON
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1:
            text = text[start:end+1]

    try:
        return json.loads(text)   # 把 JSON 字符串解析成 dict
    except json.JSONDecodeError:
        # 解析失败 — 记录日志, 返回空 dict 让上层走"降级"逻辑
        logger.warning(f"JSON 解析失败, 原始文本前200字符: {text[:200]}")
        return {}


def _call_agent(agent, query: str, max_retries: int = 2) -> dict:
    """调用智能体并解析结果

    封装了"调用 → 解析 → 重试"的完整流程。
    如果所有重试都失败, 返回一个带 error 标记的 dict。

    Args:
        agent: 智能体实例
        query: 输入文本
        max_retries: 最大重试次数
    Returns:
        dict: 解析后的结果
    """
    for attempt in range(max_retries):
        try:
            # LangGraph 的智能体调用方式: 传 {"messages": [...]} 格式
            # HumanMessage 表示"用户说的话"
            result = agent.invoke({
                "messages": [HumanMessage(content=query)]
            })
            # 取最后一条消息作为智能体的回复
            # [-1] 是 Python 索引的"倒数第一个"
            response = result["messages"][-1].content
            if response:
                parsed = _try_parse_json(response)
                if parsed:   # 成功解析出非空 dict
                    return parsed
        except Exception as e:
            logger.warning(f"智能体调用失败 (第{attempt+1}次): {e}")

    # 所有重试都失败
    return {
        "error": "智能体调用失败",
        "status": "error",
        "confidence": 0.0
    }


# 5. 构建 LangGraph 工作流图
#
# 关键设计: 节点函数定义在 build_workflow() 内部,
# 通过闭包（closure）捕获 agent 变量。
#
# 为什么这么做而不是存在 state 里?
# 因为 agent 对象包含 LLM 连接、工具列表等不可序列化的内容,
# 不适合放在 state 中传递。

def build_workflow(llm):
    """构建完整的智能体工作流

    这是整个系统的"装配线":
    1. 创建所有智能体实例
    2. 定义图结构（节点 + 边）
    3. 编译为可调用的应用

    Args:
        llm: LangChain LLM 实例
    Returns:
        CompiledStateGraph: 编译好的工作流图
    """
    # 第一步: 创建智能体实例
    # 这些变量会被内部函数通过闭包捕获
    rule_agent = create_rule_agent(llm)
    traj_agent = create_trajectory_agent(llm)
    ais_agent = create_ais_agent(llm)
    orchestrator = create_orchestrator_agent(llm)

    logger.info("所有智能体创建完成")

    # 第二步: 定义节点函数
    # 每个节点接收 state, 返回要更新的字段
    # 注意: 这些函数"看到"了外层作用域的 agent 变量（闭包）

    def parse_input_node(state: ShipAnalysisState) -> dict:
        """节点1: 数据校验 — 用 Pydantic 校验输入, 不通过就记录错误"""
        raw = state.get("raw_input", {})
        try:
            ShipData(**raw)  # **raw 是"解包", 等价于 ShipData(mmsi=..., name=..., ...)
            logger.info("输入数据校验通过")
            return {}  # 空 dict 表示"不更新 state"
        except Exception as e:
            logger.error(f"输入数据校验失败: {e}")
            # 把错误放进 state 的 errors 字段
            return {"errors": [f"校验失败: {str(e)}"]}

    def rule_engine_node(state: ShipAnalysisState) -> dict:
        """节点2: 规则引擎分析"""
        raw = state["raw_input"]
        # .get(key, {}) 一层层取, 避免 KeyError
        ship = raw.get("ship", {})
        pos = raw.get("current_position", {})
        ctx = raw.get("context", {})

        # 拼一段"人话"给 LLM 看 — 类似 PPT 大纲
        query = (
            f"请分析船舶合规性:\n"
            f"船舶: {json.dumps(ship, ensure_ascii=False)}\n"
            f"位置: ({pos.get('lat')}, {pos.get('lon')})\n"
            f"航速: {pos.get('speed')} 节 | "
            f"区域: {ctx.get('current_zone', '未知')} | "
            f"时间: {ctx.get('time_info', '未知')} | "
            f"类型: {ship.get('ship_type', '未知')}"
        )

        result = _call_agent(rule_agent, query)
        logger.info(f"规则引擎: {result.get('status', 'unknown')}")
        return {"rule_result": result}

    def trajectory_node(state: ShipAnalysisState) -> dict:
        """节点3: 轨迹分析"""
        raw = state["raw_input"]
        ship = raw.get("ship", {})
        pos = raw.get("current_position", {})
        history = raw.get("history", [])

        query = (
            f"请分析轨迹异常:\n"
            f"MMSI: {ship.get('mmsi')} | 类型: {ship.get('ship_type')}\n"
            f"航速: {pos.get('speed')} 节 | 航向: {pos.get('course')}°\n"
            f"状态: {pos.get('status', '未知')}\n"
            f"历史点数: {len(history)}\n"
            # json.dumps(..., default=str): 不能序列化的对象用 str() 兜底
            f"前5个点: {json.dumps(history[:5], ensure_ascii=False, default=str)}"
        )

        result = _call_agent(traj_agent, query)
        logger.info(f"轨迹分析: {result.get('status', 'unknown')}")
        return {"trajectory_result": result}

    def ais_node(state: ShipAnalysisState) -> dict:
        """节点4: AIS验证"""
        raw = state["raw_input"]
        ship = raw.get("ship", {})
        pos = raw.get("current_position", {})

        query = (
            f"请验证AIS数据:\n"
            f"MMSI: {ship.get('mmsi')} | 船名: {ship.get('name', '未知')}\n"
            f"类型: {ship.get('ship_type', '未知')}\n"
            f"位置: ({pos.get('lat')}, {pos.get('lon')}) | "
            f"航速: {pos.get('speed')} 节"
        )

        result = _call_agent(ais_agent, query)
        logger.info(f"AIS验证: {result.get('status', 'unknown')}")
        return {"ais_result": result}

    def synthesize_node(state: ShipAnalysisState) -> dict:
        """节点5: 综合判决 — Orchestrator 做最终判断

        这一步是关键: 前面 3 个智能体可能"各说各话",
        主控智能体要把它们"调和"成一个统一结论。
        """
        rule = state.get("rule_result", {})
        traj = state.get("trajectory_result", {})
        ais = state.get("ais_result", {})

        # 如果某个子智能体返回了错误, 记录它
        errors = state.get("errors", [])

        query = (
            "请综合以下三个专家的分析结果, 给出最终违规判定:\n\n"
            f"【规则引擎】\n{json.dumps(rule, ensure_ascii=False, indent=2)}\n\n"
            f"【轨迹分析】\n{json.dumps(traj, ensure_ascii=False, indent=2)}\n\n"
            f"【AIS验证】\n{json.dumps(ais, ensure_ascii=False, indent=2)}"
        )

        result = _call_agent(orchestrator, query)

        if not result:
            # 极端情况: 主控智能体也失败了 → 用降级方案
            # 至少把子智能体的发现保留下来, 别让用户看到一片空白
            result = {
                "violation_detected": False,
                "violation_type": None,
                "violation_label": "分析异常",
                "confidence": 0.0,
                "risk_level": "low",
                "evidence_chain": [
                    {"agent_name": "RuleEngine",
                     "finding": str(rule.get("findings", "无数据")),
                     "confidence": rule.get("confidence", 0)},
                    {"agent_name": "Trajectory",
                     "finding": str(traj.get("anomalies", "无数据")),
                     "confidence": traj.get("confidence", 0)},
                    {"agent_name": "AISValidator",
                     "finding": str(ais.get("findings", "无数据")),
                     "confidence": ais.get("confidence", 0)},
                ],
                "final_assessment": "主控智能体分析异常, 基于子智能体原始数据生成",
                "recommended_action": "manual_review",
            }

        # setdefault(key, default): errors 不存在就创建, 存在就拿到原 list
        if errors:
            result.setdefault("errors", []).extend(errors)

        logger.info(
            f"综合判决完成: 违规={'是' if result.get('violation_detected') else '否'}, "
            f"置信度={result.get('confidence', 0):.1%}"
        )
        return {"final_result": result}

    # 第三步: 定义图结构
    # StateGraph 用 TypedDict 定义状态结构
    workflow = StateGraph(ShipAnalysisState)

    # 注册节点（"register" — 告诉图"我有这些处理步骤"）
    workflow.add_node("parse_input", parse_input_node)
    workflow.add_node("rule_engine", rule_engine_node)
    workflow.add_node("trajectory", trajectory_node)
    workflow.add_node("ais", ais_node)
    workflow.add_node("synthesize", synthesize_node)

    # 定义边 — 决定执行顺序
    # START 是图起点常量, END 是图终点常量
    # 这串边的意思是: 严格按顺序执行, 不分叉
    workflow.add_edge(START, "parse_input")
    workflow.add_edge("parse_input", "rule_engine")
    workflow.add_edge("rule_engine", "trajectory")
    workflow.add_edge("trajectory", "ais")
    workflow.add_edge("ais", "synthesize")
    workflow.add_edge("synthesize", END)

    # 第四步: 编译
    # compile() 会做拓扑排序、类型检查等
    app = workflow.compile()
    logger.info("工作流图编译完成")

    return app


# 6. 高层接口 — 智能体系统主入口（Facade 外观模式）

class ShipViolationDetector:
    """船舶违规检测器 — 对外统一接口

    这是整个系统的门面（Facade 模式）。
    调用者只需要:
    1. 创建一个检测器
    2. 调用 analyze(ship_data)
    3. 获取结果
    不需要关心内部的智能体如何协作。

    使用示例:
        llm = ChatOllama(model="qwen2.5:7b-instruct-q4_K_M")
        detector = ShipViolationDetector(llm)
        result = detector.analyze(ship_data_dict)
    """

    def __init__(self, llm):
        """初始化检测器

        Args:
            llm: 配置好的 LangChain LLM 实例
        """
        self.llm = llm
        self.workflow = build_workflow(llm)
        logger.info("🚀 船舶违规检测器初始化完成")

    # ──────────────────────────────────────────────
    # 快速预过滤：0 LLM 调用，纯算法判断
    # ──────────────────────────────────────────────

    def _fast_prefilter(self, ship_data: dict) -> dict | None:
        """纯算法预过滤，0 LLM 调用。

        直接调用 tools.py 中的纯算法函数（geo_fence_check、speed_analysis、
        trajectory_analysis），快速判断船舶是否可疑。
        正常船直接返回 None，跳过后续 4 次 LLM 调用。

        Args:
            ship_data: 船舶数据字典

        Returns:
            None: 一切正常，无需 LLM 深度分析
            dict: 包含触发原因和详细数据，需要继续 LLM 分析
        """
        pos = ship_data.get("current_position", {})
        ship = ship_data.get("ship", {})
        history = ship_data.get("history", [])

        # 1. 地理围栏检查（纯几何判断）
        # 注: @tool 装饰器将函数包装为 StructuredTool，通过 .func 访问原始函数
        geo_result = geo_fence_check.func(
            lat=pos.get("lat", 0),
            lon=pos.get("lon", 0),
            ship_type=ship.get("ship_type"),
        )
        in_restricted = geo_result.get("is_restricted", False)
        restricted_zones = geo_result.get("in_zones", [])

        # 从地理围栏结果中提取限速
        speed_limit = None
        for r in geo_result.get("restrictions", []):
            for limit_desc in r.get("limits", []):
                if "限速" in limit_desc:
                    try:
                        speed_limit = float(
                            limit_desc.replace("限速", "").replace("节", "").strip()
                        )
                    except ValueError:
                        pass

        # 2. 速度分析（纯统计计算）
        speed_result = speed_analysis.func(
            mmsi=ship.get("mmsi", ""),
            current_speed=pos.get("speed", 0),
            history=history,
            zone_speed_limit=speed_limit,
        )

        # 3. 轨迹分析（纯迭代计算）
        traj_result = trajectory_analysis.func(
            mmsi=ship.get("mmsi", ""),
            history=history,
            current_position=pos,
        )

        # 综合判断：有任何异常标记就触发 LLM 深度分析
        flags = []
        if in_restricted:
            flags.append(f"在管制区内: {', '.join(restricted_zones)}")
        if speed_result.get("is_violation"):
            flags.extend(speed_result.get("violations", []))
        if traj_result.get("has_anomaly"):
            anomalies = traj_result.get("anomalies", [])
            flags.append(f"轨迹异常: {len(anomalies)} 处")

        if flags:
            logger.info(f"⚠️  预过滤触发: {'; '.join(flags)}")
            return {
                "reason": "; ".join(flags),
                "details": {
                    "geo": geo_result,
                    "speed": speed_result,
                    "traj": traj_result,
                },
            }

        logger.debug(f"✅ 预过滤通过: {ship.get('mmsi', '未知')}")
        return None

    # ──────────────────────────────────────────────
    # 主分析入口
    # ──────────────────────────────────────────────

    def analyze(self, ship_data: dict) -> dict:
        """分析单条船舶数据 — 主入口

        执行流程:
        1. 快速预过滤（纯算法，0 LLM）
        2. 如果预过滤通过 → 直接返回正常结果
        3. 如果预过滤触发 → 走 LLM 工作流深度分析

        Args:
            ship_data: 符合 ShipData 格式的船舶数据字典

        Returns:
            dict: 违规判定结果, 结构见 ViolationResult
        """
        mmsi = ship_data.get("ship", {}).get("mmsi", "unknown")
        logger.info(f"▶ 开始分析船舶: {mmsi}")

        # ── 第一步：快速预过滤（0 LLM 调用） ──
        prefilter_result = self._fast_prefilter(ship_data)
        if prefilter_result is None:
            logger.info(f"✅ {mmsi} 预过滤判定正常，跳过 LLM 分析")
            return ViolationResult(
                violation_detected=False,
                confidence=0.95,
                risk_level="low",
                recommended_action="monitor",
                final_assessment="经快速检测：船舶位置正常、速度正常、轨迹无异常，未发现违规行为。",
                evidence_chain=[
                    AgentFinding(
                        agent_name="FastPreFilter",
                        finding="地理围栏/速度/轨迹三项检查均通过",
                        confidence=0.95,
                    ).model_dump()
                ],
            ).model_dump()

        logger.info(f"🔍 {mmsi} 触发深度分析: {prefilter_result['reason']}")
        # ── 预过滤结束 ──

        try:
            # 初始化状态
            initial_state: ShipAnalysisState = {
                "raw_input": ship_data,
                "rule_result": None,
                "trajectory_result": None,
                "ais_result": None,
                "final_result": None,
                "errors": [],
            }

            # 执行工作流
            final_state = self.workflow.invoke(initial_state)
            result = final_state.get("final_result", {})

            if not result:
                result = ViolationResult(
                    final_assessment="工作流未产生有效结果",
                    errors=["empty result"],
                ).model_dump()

            return result

        except Exception as e:
            logger.error(f"❌ 分析过程异常: {e}")
            return ViolationResult(
                violation_detected=False,
                final_assessment=f"系统内部错误: {str(e)}",
                errors=[f"分析异常: {str(e)}"],
                recommended_action="monitor",
            ).model_dump()

    def analyze_batch(
        self, ships_data: list, max_workers: int = 4
    ) -> list[dict]:
        """并行批量分析多条船舶。

        船与船之间完全独立，使用 ThreadPoolExecutor 并行处理。
        ChatOllama 是 I/O 密集型（HTTP 调用），线程池最适合。

        Args:
            ships_data: ShipData 格式的字典列表
            max_workers: 并行数，默认 4

        Returns:
            list[dict]: 按原始顺序排列的分析结果
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed

        total = len(ships_data)
        logger.info(f"▶ 批量分析 {total} 条船舶 (并行数={max_workers})")

        # 提交所有任务
        future_to_idx = {}
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            for i, ship in enumerate(ships_data):
                future = executor.submit(self.analyze, ship)
                future_to_idx[future] = (i, ship)

            # 按完成顺序收集（用 list 暂存，最后排序）
            indexed_results: list[tuple[int, dict]] = []
            for future in as_completed(future_to_idx):
                i, ship = future_to_idx[future]
                try:
                    result = future.result()
                    # 补充船舶标识
                    result["mmsi"] = ship.get("ship", {}).get("mmsi", "")
                    result["ship_name"] = ship.get("ship", {}).get("name", "") or ""
                    result["ship_type"] = (
                        ship.get("ship", {}).get("ship_type", "") or ""
                    )
                    indexed_results.append((i, result))
                except Exception as e:
                    logger.error(f"船舶 [{i+1}/{total}] 分析失败: {e}")
                    indexed_results.append((
                        i,
                        {
                            "mmsi": ship.get("ship", {}).get("mmsi", ""),
                            "ship_name": ship.get("ship", {}).get("name", "") or "",
                            "ship_type": ship.get("ship", {}).get("ship_type", "") or "",
                            "violation_detected": False,
                            "violation_type": None,
                            "violation_label": None,
                            "confidence": 0.0,
                            "risk_level": "low",
                            "recommended_action": "monitor",
                            "final_assessment": f"分析异常: {str(e)}",
                            "evidence_chain": [],
                            "errors": [f"分析异常: {str(e)}"],
                        },
                    ))

        # 按原始顺序排序后返回
        indexed_results.sort(key=lambda x: x[0])
        results = [r[1] for r in indexed_results]

        if total:
            violations = sum(1 for r in results if r.get("violation_detected"))
            logger.info(
                f"📊 批量完成: {total} 艘, 违规 {violations} 艘 "
                f"({violations/total*100:.1f}%)"
            )
        else:
            logger.info("📊 批量完成: 0 艘")
        return results
