"""
ship_agent — 船舶违规检测智能体核心包

提供:
  - ShipViolationDetector: 违规检测主入口
  - tools: 地理围栏、速度分析、轨迹分析等工具
  - models: 输入/输出数据模型

使用方式:
  from ship_agent.agents import ShipViolationDetector
  from langchain_community.chat_models import ChatOllama

  llm = ChatOllama(model="qwen2.5:7b-instruct-q4_K_M")
  detector = ShipViolationDetector(llm)
  result = detector.analyze(ship_data)
"""

__version__ = "1.0.0"
