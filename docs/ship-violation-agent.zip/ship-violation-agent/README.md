# 船舶违规检测智能体

基于 **LangChain + LangGraph** 的多智能体系统，输入船舶 AIS 数据，自动判定是否有违规行为。

## 系统架构

```
输入船舶数据 → 规则引擎智能体 → 轨迹分析智能体 → AIS验证智能体 → 主控智能体(综合判决) → 违规判定
```

| 智能体 | 角色 | 工具 |
|-------|------|------|
| **规则引擎** | 检查区域法规匹配 | `geo_fence_check`, `query_regulation` |
| **轨迹分析** | 检测速度/轨迹异常 | `speed_analysis`, `trajectory_analysis` |
| **AIS验证** | 评估数据可信度 | `ship_registry_lookup`, `trajectory_analysis` |
| **主控智能体** | 综合判决 | 分析子智能体结果 |

## 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 安装 Ollama 并下载模型

```bash
# 安装 Ollama: https://ollama.com
ollama pull qwen2.5:7b-instruct-q4_K_M
```

### 3. 运行

```bash
python main.py
```

### 输出示例

```
▶ 开始分析船舶: 412345678
规则引擎分析完成: 违规待确认
轨迹分析完成: 异常待确认
AIS验证完成: 数据可信

📋 违规判定结果
🔴 违规判定: 违规!
   ├─ 违规类型: illegal_fishing_in_protected_zone
   ├─ 违规描述: 禁渔区非法捕捞
   ├─ 置信度: 93.0%
   └─ 建议操作: auto_alert

📎 证据链 (3 条)
  [1] RuleEngineAgent — 禁渔区A内，当前为禁渔期
  [2] TrajectoryAgent — 航速从11节骤降至0.8节，符合捕捞特征
  [3] AISValidatorAgent — 数据可信
```

## 项目结构

```
ship-violation-agent/
├── main.py                   # 运行入口
├── requirements.txt          # 依赖清单
├── regulations.json          # 规则库（电子围栏、限速、禁渔期）
├── ship_agent/               # 智能体核心包
│   ├── __init__.py
│   ├── models.py             # 数据模型（Pydantic）
│   ├── config.py             # 配置文件
│   ├── tools.py              # 工具函数（地理围栏、速度分析等）
│   └── agents.py             # 智能体定义 + LangGraph工作流
├── logs/                     # 日志文件
└── output/                   # 分析结果输出
```

## 自定义规则

编辑 `regulations.json` 添加：
- **zones**: 电子围栏区域（禁渔区、限速区等）
- **ship_types**: 船舶类型分类
- **violation_types**: 违规类型及处罚标准

## 关键技术

- **LangChain**: LLM 应用框架
- **LangGraph**: 多智能体工作流编排
- **Qwen2.5-7B**: 本地运行的 LLM（通过 Ollama）
- **Pydantic v2**: 数据模型校验
- **Shapely**: 地理空间计算（点、多边形碰撞检测）
